import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.WindowConstants;

public class Checkers extends JFrame implements MouseListener {	

	int boardPieces[][];
	int title_bar_height = 23;
	int squares_per_side = 8;
	int pixels_per_side = 560;
	GameBoard gb;

	public static void main(String[] args) {  
		new Checkers();  
	}
	
	public Checkers(){  
		
		//set up our game variables
		boardPieces = new int[squares_per_side][squares_per_side];
		setupPieces();
				
		gb = new GameBoard(pixels_per_side, squares_per_side, boardPieces);
		add(gb);
		
		//set a few things for our JFrame
		setSize(pixels_per_side, pixels_per_side + title_bar_height - 1);  
		setVisible(true);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		addMouseListener(this);
		
	} 
	
	private void setupPieces(){
		
		boardPieces[0][0] = 2;
		boardPieces[2][0] = 2;
		boardPieces[4][0] = 2;
		boardPieces[6][0] = 2;
		boardPieces[1][1] = 2;
		boardPieces[3][1] = 2;
		boardPieces[5][1] = 2;
		boardPieces[7][1] = 2;
		boardPieces[0][2] = 2;
		boardPieces[2][2] = 2;
		boardPieces[4][2] = 2;
		boardPieces[6][2] = 2;

		boardPieces[1][5] = 1;
		boardPieces[3][5] = 1;
		boardPieces[5][5] = 1;
		boardPieces[7][5] = 1;
		boardPieces[0][6] = 1;
		boardPieces[2][6] = 1;
		boardPieces[4][6] = 1;
		boardPieces[6][6] = 1;
		boardPieces[1][7] = 1;
		boardPieces[3][7] = 1;
		boardPieces[5][7] = 1;
		boardPieces[7][7] = 1;	
	}

	public void mouseClicked(MouseEvent e) {
		
		int sq_pixels = pixels_per_side / squares_per_side;
		
			//getInsets() asks the window how thick its own border and title bar actually are.
		//They are different sizes on Mac, Windows and Linux, so we can't hard-code a number -
		//doing that makes every click land one row off on the platforms where it's wrong.
		java.awt.Insets insets = getInsets();

		int selectedX = (e.getX() - insets.left) / sq_pixels; 
		int selectedY = (e.getY() - insets.top) / sq_pixels;

		//ignore clicks that land outside the 8x8 board
		if(selectedX < 0 || selectedX >= squares_per_side || selectedY < 0 || selectedY >= squares_per_side){
			return;
		}
		
		//System.out.println("click " + selectedX + " " + selectedY);
		
		//only allow if black square
		if( (selectedX + selectedY) % 2 == 0){
			gb.setSelectedSquare(new Point(selectedX, selectedY));			
		}else{
			gb.setSelectedSquare(null);
		}
		
		this.repaint();

	}
	
	
	
	
	
	/* not using the following mouse listener methods, but need these here */
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
	}
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub		
	}
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub	
	}
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub	
	}


}
