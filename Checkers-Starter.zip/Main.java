/**
 * JuiceMind runs the class called Main, so this just launches the real game.
 * All the actual code lives in Checkers.java.
 */
public class Main {
    public static void main(String[] args) {
        new Checkers();
    }
}
