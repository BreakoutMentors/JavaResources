import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

import javax.swing.JPanel;

public class GameBoard extends JPanel {
		
		private int BOARD_SIDE_PIXELS;
		private int BOARD_SIDE_SQUARES;
		private int SQUARE_PIXELS;
		private int BOARD_PIECES[][];
		private Point SELECTED_SQUARE;

		public GameBoard(int pixels_per_side, int squares_per_side, int boardPieces[][]){
			
			BOARD_SIDE_PIXELS = pixels_per_side;
			BOARD_SIDE_SQUARES = squares_per_side;
			SQUARE_PIXELS = pixels_per_side / squares_per_side;
			BOARD_PIECES = boardPieces;
			
		}
		
		public void paintComponent(Graphics g) { 

			super.paintComponent(g);
			
			//drawSeparatorLines(g);
			drawSquareBackgroundColors(g);
			drawPieces(g);
			drawSelectedSquare(g);

	    }
		
		public void setSelectedSquare(Point sq){
			SELECTED_SQUARE = sq;
		}
		
		private void drawSelectedSquare(Graphics g){
			
			if(SELECTED_SQUARE != null){
				g.setColor(Color.YELLOW);
				
				//do several so a bit thicker
				for(int i=0; i<5; i++){
					g.drawRect(SELECTED_SQUARE.x * SQUARE_PIXELS + i, SELECTED_SQUARE.y * SQUARE_PIXELS + i, SQUARE_PIXELS - i*2, SQUARE_PIXELS - i*2);
				}
			}
		}
		
		//not used for checkers, will be used for other games
		private void drawSeparatorLines(Graphics g){
			
			//horizontal lines
			for(int i=1; i<BOARD_SIDE_SQUARES; i++){
				//x is always 0 to board size
				g.drawLine(0, i*SQUARE_PIXELS, BOARD_SIDE_PIXELS, i*SQUARE_PIXELS);
			}
			
			//vertical lines
			for(int i=1; i<BOARD_SIDE_SQUARES; i++){
				//y is always 0 to board size
				g.drawLine(i*SQUARE_PIXELS, 0, i*SQUARE_PIXELS, BOARD_SIDE_PIXELS);
			}
			
		}
		
		private void drawSquareBackgroundColors(Graphics g){
			
			for(int i=0; i<BOARD_SIDE_SQUARES; i++){
				
				//every even row/col starts with black
				int startPosition = i % 2;
				
				//start at the right position and count by 2
				for(int j=startPosition; j<BOARD_SIDE_SQUARES; j=j+2){
					g.fillRect(i * SQUARE_PIXELS, j*SQUARE_PIXELS, SQUARE_PIXELS, SQUARE_PIXELS);
				}
			}
		}
		
		private void drawPieces(Graphics g){
			
			//leave a little space between the edge of the square
			int pixelBuffer = 8;
			
			for(int i=0; i<BOARD_SIDE_SQUARES; i++){
				for(int j=0; j<BOARD_SIDE_SQUARES; j++){
					
					int piece = BOARD_PIECES[i][j];
					if(piece != 0){
						
						if(piece == 1) g.setColor(Color.BLUE);
						if(piece == 2) g.setColor(Color.RED);

						g.fillOval(i * SQUARE_PIXELS + pixelBuffer, j*SQUARE_PIXELS + pixelBuffer, SQUARE_PIXELS - pixelBuffer*2, SQUARE_PIXELS - pixelBuffer*2);
					}
					
				}
			}
			
		}
}