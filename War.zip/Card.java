public class Card {
    public final String suit;
    public final int rank;

    public Card(String suit, int value) {
        this.suit = suit;
        rank = value;
    }
    
    public String toString() {
    		if(rank > 1 && rank < 11) {
			return(rank  + "_of_" + suit);
		} else if (rank == 11) {
			return("jack_of_" + suit);
		} else if (rank == 12) {
			return("queen_of_" + suit);
		} else if (rank == 13) {
			return("king_of_" + suit);
		} else {
			return("ace_of_" + suit);
		}
    }
}
