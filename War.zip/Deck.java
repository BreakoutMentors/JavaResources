import java.util.*;

public class Deck {
	protected final LinkedList<Card> cards = new LinkedList<Card>();

	public Deck() {
		populateCards();
		shuffle();
	}

	private void populateCards() {
		for (int suit = 1; suit <= 13; suit++) {
			cards.add(new Card("clubs", suit));
		}
		for (int suit = 1; suit <= 13; suit++) {
			cards.add(new Card("diamonds", suit));
		}
		for (int suit = 1; suit <= 13; suit++) {
			cards.add(new Card("hearts", suit));
		}
		for (int suit = 1; suit <= 13; suit++) {
			cards.add(new Card("spades", suit));
		}
	}

	public Card deal() {
		return isEmpty() ? null : cards.remove();
	}

	public boolean isEmpty() {
		return cards.isEmpty();
	}

	public int size() {
		return cards.size();
	}

	public void shuffle() {
		Collections.shuffle(cards);
	}
}
