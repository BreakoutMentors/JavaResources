import java.awt.*;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class GameBoard extends JPanel {
		
		private int BOARD_SIDE_PIXELS;
		private HashMap<Card, String> deck;
		private Card activeUserCard, activeCpuCard;
		public Card userWarCard, cpuWarCard;
		public boolean war = false;
		private String labelValue = "";
		private Player user, cpu;

		public GameBoard(int pixels_per_side, HashMap<Card, String> deckMap, Player user, Player cpu){
			
			BOARD_SIDE_PIXELS = pixels_per_side;
			deck = deckMap;
			activeUserCard = activeCpuCard = null;
			this.user = user;
			this.cpu = cpu;
		}
		
		public void paintComponent(Graphics g) { 
			super.paintComponent(g);
			setBackground(Color.GREEN);
			g.drawLine(0, BOARD_SIDE_PIXELS, BOARD_SIDE_PIXELS, BOARD_SIDE_PIXELS);
			drawDecks(g);
			drawActiveCards(g);
			drawLabel(g);
			drawCardCount(g);
		}
		
		private void drawCardCount(Graphics g) {
			
			g.drawString("You: " + user.cards.size() + " cards", 470, 330);
			g.drawString("CPU: " + cpu.cards.size() + " cards", 470, 690);
		}

		private void drawActiveCards(Graphics g) {
			BufferedImage userCard = (activeUserCard == null) ? null : getImage("cards/" + deck.get(activeUserCard) + ".png");
			BufferedImage cpuCard = (activeCpuCard == null) ? null : getImage("cards/" + deck.get(activeCpuCard) + ".png");
			
			
			if(!war) {
				g.drawImage(userCard,  10,  10,  this);
				g.drawImage(cpuCard, 10, 370, this);
			} else {
				BufferedImage userFinal = (userWarCard == null) ? null : getImage("cards/" + deck.get(userWarCard) + ".png");
				BufferedImage cpuFinal = (cpuWarCard == null) ? null : getImage("cards/" + deck.get(cpuWarCard) + ".png");
				
				g.drawImage(userCard,  10,  10,  this);
				g.drawImage(cpuCard, 10, 370, this);
				
				int x = 40;
				for(int i = 0; i < War.warCards; i++) {
					BufferedImage backCard = getImage("cards/back_of_playing_card.png");
					g.drawImage(backCard, x, 10, this);
					g.drawImage(backCard, x, 370, this);
					x += 30;
				}
				g.drawImage(userFinal, x, 10, this);
				g.drawImage(cpuFinal, x, 370, this);
				
			}
			
		}

		private void drawDecks(Graphics g) {
			BufferedImage userDeck = getImage("cards/final_deck.png");
			BufferedImage cpuDeck = getImage("cards/final_deck.png");
			
			g.drawImage(userDeck,  470,  10,  this);
			g.drawImage(cpuDeck, 470, 370, this);
		}
		
		private BufferedImage getImage(String filename) {
			BufferedImage after = null;
			try {
			    BufferedImage img = ImageIO.read(new File(filename));
			    BufferedImage before = img;
			    int w = before.getWidth();
			    int h = before.getHeight();
			    after = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
			    AffineTransform at = new AffineTransform();
			    at.scale(.4, .4);
			    AffineTransformOp scaleOp = 
			       new AffineTransformOp(at, AffineTransformOp.TYPE_BILINEAR);
			    after = scaleOp.filter(before, after);
			} catch (IOException e) {
			}
			return after;
		}
		
		public void setActiveUserCard(Card c) {
			activeUserCard = c;
		}
		
		public void setActiveCpuCard(Card c) {
			activeCpuCard = c;
		}
	
		public void setLabel(String newValue) {
			labelValue = newValue;
		}

		private void drawLabel(Graphics g){
			g.setColor(Color.BLACK);

			//line at bottom of board
			
			Font f = new Font("ArialBlack", Font.BOLD, 30);
			g.setFont(f);
			g.drawString(labelValue, 42, BOARD_SIDE_PIXELS/2 + 10);
			
		}
}