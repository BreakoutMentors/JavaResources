import java.awt.*;
import java.awt.event.*;
import java.util.*;

import javax.swing.*;

public class War extends JFrame {
	
	//Number of interim cards during War
	public static final int warCards = 3;
	HashMap<Card, String> deckMap;
	int title_bar_height = 23;
	int squares_per_side = 8;
	int label_height = 25;
	int pixels_per_side = 750 - title_bar_height - label_height;

	private Player user, cpu;

	GameBoard gb;

	public static void main(String[] args) {  
		new War();  
	}

	public War(){  
		//set up our game variables
		deckMap = new HashMap<Card, String>();
		user = new Player();
		cpu = new Player();
		setupMap();

		JButton btn = new JButton("Flip Card");
		btn.setBounds(pixels_per_side/2 - 40, pixels_per_side-1, 80, 30);
		btn.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) { 
				if(!gameOver()) {
					if(gb.war) gb.war = false;
					playRound();
				}
			}
		});
		add(btn);

		
		gb = new GameBoard(pixels_per_side, deckMap, user, cpu);
		add(gb);

		//set a few things for our JFrame
		setSize(pixels_per_side, pixels_per_side + title_bar_height + label_height);  
		setVisible(true);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

	}

	private void playRound() {
		Card userCard = user.cards.drawCard();
		gb.setActiveUserCard(userCard);
		Card cpuCard = cpu.cards.drawCard();
		gb.setActiveCpuCard(cpuCard);

		if(userCard.rank > cpuCard.rank) {
			gb.setLabel("You won");
			user.cards.add(cpuCard);
			user.cards.add(userCard);
		} else if (userCard.rank < cpuCard.rank) {
			gb.setLabel("CPU won");
			cpu.cards.add(userCard);
			cpu.cards.add(cpuCard);
		} else {
			gb.setLabel("The cards were the same, WAR");
			ArrayList<Card> cards = new ArrayList<Card>();
			playWar(userCard, cpuCard, cards);
		}
		this.repaint();
	}

	private void playWar(Card userCard, Card cpuCard, ArrayList<Card> cards) {
		gb.war = true;
		ArrayList<Card> faceDownCards = new ArrayList<Card>();
		ArrayList<Card> cardsToAdd =  new ArrayList<>(Arrays.asList(cpuCard, userCard));
		cardsToAdd.addAll(cards);
		
		for(int i = 0; i < warCards; i++) {
			Card userFaceDown = (user.cards.isEmpty()) ? null : user.cards.drawCard();
			Card cpuFaceDown = (cpu.cards.isEmpty()) ? null : cpu.cards.drawCard();
			
			if(userFaceDown == null) {
				gb.setLabel("You do not have a card left, CUP won war");
				faceDownCards.add(cpuFaceDown);
				cpu.cards.add(cardsToAdd);
				return;
			}

			if(cpuFaceDown == null) {
				gb.setLabel("The CPU does not have a card left, you won war");
				faceDownCards.add(userFaceDown);
				user.cards.add(cardsToAdd);
				return;
			}
			
			faceDownCards.add(userFaceDown);
			faceDownCards.add(cpuFaceDown);
		}
		
		cardsToAdd.addAll(faceDownCards);
		if(faceDownCards.size() != 2*warCards) {
			if(faceDownCards.size()%2 == 0) {
				gb.setLabel("The CPU does not have a card left, you won war");
				user.cards.add(cardsToAdd);
			} else {
				gb.setLabel("You do not have a card left, CUP won war");
				cpu.cards.add(cardsToAdd);
			}
			return;
		}

		Card userFinal = (user.cards.isEmpty()) ? null : user.cards.drawCard();
		Card cpuFinal = (cpu.cards.isEmpty()) ? null : cpu.cards.drawCard();
		gb.userWarCard = userFinal;
		gb.cpuWarCard = cpuFinal;

		if(userFinal != null && cpuFinal != null)  {
			cardsToAdd.add(userFinal);
			cardsToAdd.add(cpuFinal);
			cardsToAdd.addAll(cards);
			if(userFinal.rank > cpuFinal.rank) {
				gb.setLabel("YOU WON WAR!");
				user.cards.add(cardsToAdd);
			} else if (userFinal.rank < cpuFinal.rank){
				cpu.cards.add(cardsToAdd);
				gb.setLabel("CPU WON WAR!");
			} else {
				cardsToAdd.remove(userFinal);
				cardsToAdd.remove(cpuFinal);
				playWar(userFinal, cpuFinal, cardsToAdd);
			}
		} else if (cpuFinal == null) {
			gb.setLabel("The CPU does not have a card left, you won war");
			cardsToAdd.add(userFinal);
			user.cards.add(cardsToAdd);
		} else {
			gb.setLabel("You do not have a card left, CUP won war");
			cardsToAdd.add(cpuFinal);
			cpu.cards.add(cardsToAdd);
		}
	}

	private boolean gameOver() {
		return user.cards.isEmpty() || cpu.cards.isEmpty();
	}

	private void setupMap() {
		Deck deck = new Deck();
		boolean isUser = true;
		while(!deck.isEmpty()) {
			Card c = deck.deal();
			if(isUser) {
				user.addToPile(c);
				
			} else {
				cpu.addToPile(c);
			}
			isUser = !isUser;
			if(c.rank > 1 && c.rank < 11) {
				deckMap.put(c, c.rank  + "_of_" + c.suit);
			} else if (c.rank == 11) {
				deckMap.put(c, "jack_of_" + c.suit);
			} else if (c.rank == 12) {
				deckMap.put(c, "queen_of_" + c.suit);
			} else if (c.rank == 13) {
				deckMap.put(c, "king_of_" + c.suit);
			} else {
				deckMap.put(c, "ace_of_" + c.suit);
			}
		}
	}

}