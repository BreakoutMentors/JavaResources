public class Player {
    public Pile cards;
    
    public Player() {
    		cards = new Pile();
    }
    
    public void addToPile(Card c) {
    		cards.add(c);
    }
}
