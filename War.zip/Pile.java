import java.util.*;

public class Pile {
    private Queue<Card> cards;

    public Pile() {
        cards = new LinkedList<Card>();
    }

    public Pile(Collection<Card> cards) {
        this();
        add(cards);
    }

    public void add(Card card) {
        cards.add(card);
    }

    public void add(Collection<Card> cardsToAdd) {
        cards.addAll(cardsToAdd);
    }

    public Card drawCard() {
        return cards.remove();
    }

    public boolean isEmpty() {
        return cards.isEmpty();
    }

    public int size() {
        return cards.size();
    }
    
    public String toString() {
    		return cards.toString();
    }
}