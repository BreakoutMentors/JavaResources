import acm.graphics.GImage;

public class EnemyShip extends GImage {

	double SPEED = -1;
	double SCALEBOSS = .5;
	double hitPoints;
	
	public EnemyShip(int x, int y, String type){
		super("spaceship3.png", x, y);
		scale(SCALEBOSS);
		hitPoints = 10;
	}
	
	public EnemyShip(int enemyX, int enemyY, double scale) {
		super("spaceship.png", enemyX, enemyY);
		scale(.08*scale);
		hitPoints = 3;
	}

	public void takeDamage(double damage){
		hitPoints -= damage;
	}
	
	public boolean isAlive(){
		return hitPoints > 0;
	}
	

	public void moveShip(){
		move(SPEED,0);
		
		if(getX() <= 0 || getX() >= SpaceInvaders.APPLICATION_WIDTH - getWidth()){
			moveDown();
			flipDirection();
		}
	}

	public void moveDown(){
		move(0, 55);
	}

	public void flipDirection(){
		SPEED = -SPEED;
	}




}