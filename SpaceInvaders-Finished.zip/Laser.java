import java.awt.Color;

import acm.graphics.*;
public class Laser extends GRect{

	private static final int BULLET_DIAM = 5;
	private static final int BULLET_SPEED = 8;
	public final double DAMAGE = 1;
	
	public Laser(double spaceshipX, double spaceshipY){
		super(spaceshipX, spaceshipY - 25, BULLET_DIAM, BULLET_DIAM*10);
		setFilled(true);
		setColor(Color.WHITE);
	}

	public void moveUp(){	
		
		move(0, -BULLET_SPEED);
		
	}
}
