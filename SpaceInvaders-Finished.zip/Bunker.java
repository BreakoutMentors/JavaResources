import java.awt.Color;
import acm.graphics.GRect;

public class Bunker extends GRect {
	
	private static final int BUNKER_WIDTH = 100;
	private static final int BUNKER_HEIGHT = 8;
	private int HEALTH = 5;
	
	public Bunker(int x, int y) {
		super(x, y, BUNKER_WIDTH, BUNKER_HEIGHT);
		setFilled(true);
		setColor(Color.GRAY);
	}
	
	public void takeDamage() {
		HEALTH--;
	}
	
	public boolean isAlive() {
		return HEALTH > 0;
	}
}
