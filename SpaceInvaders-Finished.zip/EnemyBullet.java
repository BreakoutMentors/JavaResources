import acm.graphics.GOval;

import java.awt.Color;

import acm.graphics.GOval;

public class EnemyBullet extends GOval {
	
	private static final int BULLET_DIAM = 5;
	private static final int BULLET_SPEED = 6;
	
	public EnemyBullet(double spaceshipX, double spaceshipY){
		
		super(spaceshipX, spaceshipY, BULLET_DIAM, BULLET_DIAM);
		setFilled(true);
		setColor(Color.RED);
	}

	public void moveDown(){	
		
		move(0, BULLET_SPEED);
		
	}
	
	
	
}