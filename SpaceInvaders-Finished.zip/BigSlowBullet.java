import java.awt.Color;

import acm.graphics.*;

public class BigSlowBullet extends GOval{

	private static final int BULLET_DIAM = 10;
	private static final int BULLET_SPEED = 4;
	public final double DAMAGE = 2;
	
	public BigSlowBullet(double spaceshipX, double spaceshipY){
		
		super(spaceshipX, spaceshipY, BULLET_DIAM, BULLET_DIAM);
		setFilled(true);
		setColor(Color.WHITE);
	}

	public void moveUp(){	
		
		move(0, -BULLET_SPEED);
		
	}
}
