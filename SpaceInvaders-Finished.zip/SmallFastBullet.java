import java.awt.Color;

import acm.graphics.*;

public class SmallFastBullet extends GOval {

	private static final int BULLET_DIAM = 2;
	private static final int BULLET_SPEED = 16;
	public final double DAMAGE = .5;
	
	public SmallFastBullet(double spaceshipX, double spaceshipY){
		
		super(spaceshipX, spaceshipY, BULLET_DIAM, BULLET_DIAM);
		setFilled(true);
		setColor(Color.WHITE);
	}

	public void moveUp(){	
		
		move(0, -BULLET_SPEED);
		
	}
	
}
