/**
 * JuiceMind runs the class called Main, so this just launches the real game.
 * All the actual code lives in SpaceInvaders.java.
 */
public class Main {
    public static void main(String[] args) {
        new SpaceInvaders().start(args);
    }
}
