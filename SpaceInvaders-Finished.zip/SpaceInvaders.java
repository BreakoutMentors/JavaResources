import acm.program.*;
import acm.util.RandomGenerator;
import acm.graphics.*;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.JButton;

public class SpaceInvaders extends GraphicsProgram {

	public static final int APPLICATION_WIDTH = 800;
	public static final int APPLICATION_HEIGHT = 700;

	private static final int DELAY = 10;
	private ArrayList<Bullet> bullets = new ArrayList<Bullet>();
	private ArrayList<BigSlowBullet> bigslowbullets = new ArrayList<BigSlowBullet>();
	private ArrayList<SmallFastBullet> smallfastbullets = new ArrayList<SmallFastBullet>();
	private ArrayList<Laser> lasers = new ArrayList<Laser>();
	private ArrayList<EnemyShip> enemies = new ArrayList<EnemyShip>();
	private ArrayList<EnemyBullet> enemyBullets = new ArrayList<EnemyBullet>();
	private ArrayList<Bunker> bunkers = new ArrayList<Bunker>();
	private GImage player;
	private double scale = 1;

	private int ENEMIES_PER_ROW = 8;
	private int ENEMY_ROWS = 2;
	private int ENEMY_SEP_X = 15;
	private int ENEMY_SEP_Y = 100;

	private String activeWeapon = "Bullet";

	private RandomGenerator rgen = RandomGenerator.getInstance();

	private boolean spaceshipShot = false;

	private EnemyShip boss;

	public void run(){

		setup();
		
		while (gameOver() == false) {
			enemiesShoot();
			moveEverything();
			checkForCollisions();
			if(enemies.isEmpty()) {
				ENEMIES_PER_ROW *= 1.5;
				scale /= 1.5;
				createBunkersAndEnemies();
			}
			pause(DELAY);

		}

		showGameOverMessage();

	}
	
	private void makeBunkers() {
		Bunker bunker = new Bunker(100, 595);
		bunkers.add(bunker);
		add(bunker);
		
		Bunker bunker2 = new Bunker(300, 595);
		bunkers.add(bunker2);
		add(bunker2);
		
		Bunker bunker3 = new Bunker(500, 595);
		bunkers.add(bunker3);
		add(bunker3);
	}

	private void createBunkersAndEnemies() {
		for(int i = 0; i < bunkers.size(); i++) {
			remove(bunkers.get(i));
		}
		bunkers.clear();
		
		makeBunkers();

		for(int i = 0; i < enemyBullets.size(); i++) {
			remove(enemyBullets.get(i));
		}
		enemyBullets.clear();
		
		int enemyY = 190;
		for(int j=0;j<ENEMY_ROWS;j++){
			int enemyX = 100;
			for(int i=0; i<ENEMIES_PER_ROW;i++){
				EnemyShip enemy = new EnemyShip(enemyX, enemyY, scale);
				add(enemy);
				enemies.add(enemy);

				enemyX = (int) (enemyX + ENEMY_SEP_X + enemy.getWidth());
			}
			enemyY = enemyY + ENEMY_SEP_Y;
		}

		boss = new EnemyShip(320, 0, "boss");
		add(boss);
		enemies.add(boss);
		
	}
	
	private void enemiesShoot(){
		//roughly every second you want 1 alien to shoot?

		//this runs 100 times per second
		int randomNumber = rgen.nextInt(100);
		if(randomNumber == 34){
			//pick a random enemy to shoot at you

			int randomEnemyNumber = rgen.nextInt(enemies.size());
			EnemyShip shootingEnemy = enemies.get(randomEnemyNumber);

			EnemyBullet bullet = new EnemyBullet(shootingEnemy.getX() + 
					shootingEnemy.getWidth()/2, shootingEnemy.getY());
			add(bullet);
			enemyBullets.add(bullet);
		}

		//boss shooting
		randomNumber = rgen.nextInt(50);
		if(randomNumber == 24 && enemies.contains(boss)){
			//shoot
			EnemyBullet bullet = new EnemyBullet(boss.getX() + 
					boss.getWidth()/2, boss.getY());
			add(bullet);
			enemyBullets.add(bullet);
		}

	}


	private void showGameOverMessage(){
		GLabel gameOverMessage = new GLabel("Game Over",300,300);
		gameOverMessage.setColor(Color.WHITE);
		gameOverMessage.setFont(new Font("Arial",0,38));
		add(gameOverMessage);
	}


	private void setup() {
		
		setBackground(Color.BLACK);

		//create your spaceship
		player = new GImage("myspaceship.png", 400, 620);
		add(player);

		createBunkersAndEnemies();
		
		//add mouse listeners
		addMouseListeners();
		addKeyListeners();
	}
	
	public void keyPressed(KeyEvent e) {
		System.out.println(e.getKeyCode());
		if(e.getKeyCode() == 49) {
			activeWeapon = "Bullet";
		} else if(e.getKeyCode() == 50) {
			activeWeapon = "BigSlowBullet";
		} else if(e.getKeyCode() == 51) {
			activeWeapon = "SmallFastBullet";
		} else if(e.getKeyCode() == 52) {
			activeWeapon = "Laser";
		}
	}

	private boolean gameOver() {
		return touchingEnemyShip() || spaceshipShot;

	}

	private boolean touchingEnemyShip(){

		if(getElementAt(player.getX() - 1, player.getY()) != null){
			return true;
		}
		if(getElementAt(player.getX() + player.getWidth() + 1, 
				player.getY()) != null){
			return true;
		}

		return false;
	}


	private void moveEverything(){
		//move the bullets
		for(int i=0; i<bullets.size(); i++){
			Bullet currentBullet = bullets.get(i);
			currentBullet.moveUp();

			//if the bullet is off the screen, remove it
			if(currentBullet.getY() <= 0){
				bullets.remove(currentBullet);
				remove(currentBullet);
			}
		}

		for(int i=0; i<bigslowbullets.size(); i++){
			BigSlowBullet currentBullet = bigslowbullets.get(i);
			currentBullet.moveUp();

			//if the bullet is off the screen, remove it
			if(currentBullet.getY() <= 0){
				bigslowbullets.remove(currentBullet);
				remove(currentBullet);
			}
		}

		for(int i=0; i<smallfastbullets.size(); i++){
			SmallFastBullet currentBullet = smallfastbullets.get(i);
			currentBullet.moveUp();

			//if the bullet is off the screen, remove it
			if(currentBullet.getY() <= 0){
				smallfastbullets.remove(currentBullet);
				remove(currentBullet);
			}
		}

		for(int i=0; i<lasers.size(); i++){
			Laser currentLaser = lasers.get(i);
			currentLaser.moveUp();

			//if the bullet is off the screen, remove it
			if(currentLaser.getY() <= 0){
				smallfastbullets.remove(currentLaser);
				remove(currentLaser);
			}
		}

		//move the enemies
		for(int j=0; j<enemies.size(); j++){
			EnemyShip currentEnemy = enemies.get(j);
			currentEnemy.moveShip();
		}

		//move the enemy bullets
		for(int i=0; i<enemyBullets.size(); i++){
			EnemyBullet currentBullet = enemyBullets.get(i);
			currentBullet.moveDown();

			//if the bullet is off the screen, remove it
			if(currentBullet.getY() > APPLICATION_HEIGHT){
				enemyBullets.remove(currentBullet);
				remove(currentBullet);
			}
		}


	}


	public void mouseClicked(MouseEvent e) {

		if(gameOver() == false){

			if(activeWeapon.equals("Bullet")) {
				//create a new bullet object
				Bullet newBullet = new Bullet(player.getX() + player.getWidth()/2, player.getY());

				//add it to the screen
				add(newBullet);

				//add it to our arraylist so we can track it
				bullets.add(newBullet);
			} else if (activeWeapon.equals("BigSlowBullet")) {
				BigSlowBullet newBullet = new BigSlowBullet(player.getX() + player.getWidth()/2, player.getY());

				//add it to the screen
				add(newBullet);

				//add it to our arraylist so we can track it
				bigslowbullets.add(newBullet);
			} else if (activeWeapon.equals("SmallFastBullet")) {
				SmallFastBullet newBullet = new SmallFastBullet(player.getX() + player.getWidth()/2, player.getY());

				//add it to the screen
				add(newBullet);

				//add it to our arraylist so we can track it
				smallfastbullets.add(newBullet);
			} else if (activeWeapon.equals("Laser")) {
				Laser newLaser = new Laser(player.getX() + player.getWidth()/2, player.getY());

				//add it to the screen
				add(newLaser);

				//add it to our arraylist so we can track it
				lasers.add(newLaser);
			}

		}
	}


	public void mouseMoved(MouseEvent e) {

		if(gameOver() == false){

			player.setLocation(e.getX() - player.getWidth()/2, player.getY());
			if(player.getX() < 0){
				player.setLocation(0, player.getY());
			}
			if(player.getX() > APPLICATION_WIDTH - player.getWidth()){
				player.setLocation(APPLICATION_WIDTH - player.getWidth(), player.getY());
			}
		}
	}

	private void checkForCollisions() {

		//check each bullet to see if it hit any enemy
		for(int i=0; i<bullets.size(); i++){

			Bullet currentBullet = bullets.get(i);
			GObject collObj = getElementAt(currentBullet.getX(), currentBullet.getY());

			if(collObj != null && collObj != player){
				//remove the enemy spaceship and the bullet
				if(collObj instanceof EnemyShip){
					((EnemyShip) collObj).takeDamage(bullets.get(i).DAMAGE);
					if(((EnemyShip) collObj).isAlive() == false){
						enemies.remove(collObj);
						remove(collObj);
					}

					bullets.remove(currentBullet);
					remove(currentBullet);
				}


			}
		}

		for(int i=0; i<bigslowbullets.size(); i++){

			BigSlowBullet currentBullet = bigslowbullets.get(i);
			GObject collObj = getElementAt(currentBullet.getX(), currentBullet.getY());

			if(collObj != null && collObj != player){
				//remove the enemy spaceship and the bullet
				if(collObj instanceof EnemyShip){
					((EnemyShip) collObj).takeDamage(bigslowbullets.get(i).DAMAGE);

					if(((EnemyShip) collObj).isAlive() == false){
						enemies.remove(collObj);
						remove(collObj);
					}

					bigslowbullets.remove(currentBullet);
					remove(currentBullet);
				}


			}
		}

		for(int i=0; i<smallfastbullets.size(); i++){

			SmallFastBullet currentBullet = smallfastbullets.get(i);
			GObject collObj = getElementAt(currentBullet.getX(), currentBullet.getY());

			if(collObj != null && collObj != player){
				//remove the enemy spaceship and the bullet
				if(collObj instanceof EnemyShip){
					((EnemyShip) collObj).takeDamage(smallfastbullets.get(i).DAMAGE);

					if(((EnemyShip) collObj).isAlive() == false){
						enemies.remove(collObj);
						remove(collObj);
					}

					smallfastbullets.remove(currentBullet);
					remove(currentBullet);
				}


			}
		}

		for(int i=0; i<lasers.size(); i++){

			Laser currentLaser = lasers.get(i);
			GObject LTcollObj = getElementAt(currentLaser.getX(), currentLaser.getY());
			GObject RTcollObj = getElementAt(currentLaser.getX() + 5, currentLaser.getY());
			GObject LBcollObj = getElementAt(currentLaser.getX(), currentLaser.getY()+ 50);
			GObject RBcollObj = getElementAt(currentLaser.getX() + 5, currentLaser.getY()+ 50);

			if(LTcollObj instanceof EnemyShip){
				((EnemyShip) LTcollObj).takeDamage(lasers.get(i).DAMAGE);

				if(((EnemyShip) LTcollObj).isAlive() == false){
					enemies.remove(LTcollObj);
					remove(LTcollObj);
				}
				lasers.remove(currentLaser);
				remove(currentLaser);
			} else if(RTcollObj instanceof EnemyShip){
				((EnemyShip) RTcollObj).takeDamage(lasers.get(i).DAMAGE);

				if(((EnemyShip) RTcollObj).isAlive() == false){
					enemies.remove(RTcollObj);
					remove(RTcollObj);
				}
				lasers.remove(currentLaser);
				remove(currentLaser);
			} else if(RBcollObj instanceof EnemyShip){
				((EnemyShip) RBcollObj).takeDamage(lasers.get(i).DAMAGE);

				if(((EnemyShip) RBcollObj).isAlive() == false){
					enemies.remove(RBcollObj);
					remove(RBcollObj);
				}
				lasers.remove(currentLaser);
				remove(currentLaser);
			} else if(LBcollObj instanceof EnemyShip){
				((EnemyShip) LBcollObj).takeDamage(lasers.get(i).DAMAGE);

				if(((EnemyShip) LBcollObj).isAlive() == false){
					enemies.remove(LBcollObj);
					remove(LBcollObj);
					
				}
				lasers.remove(currentLaser);
				remove(currentLaser);
				
			}

			
		}


		//check each enemy bullet to see if it hit you
		for(int j=0; j<enemyBullets.size();j++){
			EnemyBullet currentBullet = enemyBullets.get(j);

			GObject collObj = getElementAt(currentBullet.getX(), 
					currentBullet.getY()+currentBullet.getHeight());
			if(collObj == player){
				spaceshipShot = true;
			} else if (collObj instanceof Bunker) {
				((Bunker) collObj).takeDamage();
				
				if(!((Bunker) collObj).isAlive()) {
					bunkers.remove(collObj);
					remove(collObj);
				}
				
				remove(currentBullet);
				enemyBullets.remove(currentBullet);
			}
		}


	}



}