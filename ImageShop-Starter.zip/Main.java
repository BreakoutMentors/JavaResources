/**
 * JuiceMind runs the class called Main, so this just launches the real program.
 * The part you write is in ImageShopAlgorithms.java.
 */
public class Main {
    public static void main(String[] args) {
        new ImageShop().start(args);
    }
}
