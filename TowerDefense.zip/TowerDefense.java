import java.awt.event.MouseEvent;
import java.util.ArrayList;
import acm.program.GraphicsProgram;


/*
 * TOWER DEFENSE!
 * --------------
 * Detect when an enemy is hit
 * Add money/points and the ability to create new towers
 * Give towers a range
 * Add new tower types
 * Create a flow of enemies at the beginning of the level
 * Add new enemy types
 * Create new levels
 * Any other features you want!
 */
	

public class TowerDefense extends GraphicsProgram{

	public final static int APPLICATION_WIDTH = 800;
	public final static int APPLICATION_HEIGHT = 500;
	public final static int TILE_SIZE = 25;

	private static GameBackground map;
	private ArrayList<Tower> towers = new ArrayList<Tower>();
	private ArrayList<Enemy> enemies = new ArrayList<Enemy>();
	private ArrayList<Bullet> bullets = new ArrayList<Bullet>();

	
	public static TowerDefense game;

	
	public void run() {
		
		setup();
		
		gameLoop();
	}
	
	
	private void setup(){
		
		setSize(APPLICATION_WIDTH, APPLICATION_HEIGHT);
		game = this;
		
		map = new GameBackground();
		map.load("src/levels/level1.txt");
		add(map);
		
		Enemy first_enemy = new Enemy();
		enemies.add(first_enemy);
		add(first_enemy);
		
		Tower first_tower = new Tower(5,6);
		towers.add(first_tower);
		add(first_tower);
		
		addMouseListeners();
		
	}
	
	private void gameLoop(){
		
		while(true){
			
			for(Enemy currEnemy : enemies){
				currEnemy.move();
			}
			
			for(Tower currTower : towers){
				currTower.tryShoot(enemies);
			}
			
			for(Bullet currBullet : bullets){
				currBullet.move();
			}
			
			
			pause(25);
			
		}
	}
	
	public GameBackground getMap(){
		return map;
	}


	public void addBullet(Bullet bt) {
		bullets.add(bt);
		add(bt);
	}
	
	public void mouseClicked(MouseEvent e) {
		int x = e.getX();
		int y = e.getY();
		int square_x = x / TILE_SIZE;
		int square_y = y / TILE_SIZE;
		
		System.out.println("Tile x: " + square_x + ", Tile y: " + square_y);
		
		//NOT FINISHED - create new towers if you have enough money
	}
	
	
}