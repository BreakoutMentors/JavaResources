import acm.graphics.GOval;


public class Bullet extends GOval{

	private int SPEED = 8;
	private double xDir;
	private double yDir;

	
	public Bullet(Tower tower, Enemy enemy){
		
		super(tower.getX() + 12.5, tower.getY() + 12.5, 5, 5);
		setFilled(true);
		
		double x_dif =  enemy.getX() - tower.getX() ;
		double y_dif = enemy.getY() - tower.getY();
		
		//a2 + b2 = c2
		double hyp = Math.sqrt(x_dif*x_dif + y_dif*y_dif);

		//the shot direction scalar for x and y
		xDir = x_dif / hyp;
		yDir = y_dif / hyp;
	}

	//can set a range for the bullet
	public void move() {
	
		move(xDir * SPEED, yDir * SPEED);
		
	}
	
	

}