import java.awt.Graphics;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.imageio.ImageIO;

import acm.graphics.GRect;

/*
 * Art: http://opengameart.org/content/tileset-for-tile2map-with-tsx
 * http://www.lostgarden.com/2009/03/dancs-miraculously-flexible-game.html
 */

public class GameBackground extends GRect{

	
	private int[][] squares;
	private int horizontal_squares;
	private int vertical_squares;
	private int square_size;
	private BufferedImage[] boardTileImages = new BufferedImage[7];
	
	public GameBackground(){
		super(0,0, TowerDefense.APPLICATION_WIDTH, TowerDefense.APPLICATION_HEIGHT);
		
		horizontal_squares = TowerDefense.APPLICATION_WIDTH / TowerDefense.TILE_SIZE;
		vertical_squares = TowerDefense.APPLICATION_HEIGHT / TowerDefense.TILE_SIZE;
		square_size = TowerDefense.TILE_SIZE;
		
		squares = new int[horizontal_squares][vertical_squares];
		
		setupImages();
		
	}
	
	private void setupImages(){
		
		try {
			boardTileImages[0] = ImageIO.read(new File("src/resources/grass.png"));
			boardTileImages[1] = ImageIO.read(new File("src/resources/path1.png"));
			boardTileImages[2] = ImageIO.read(new File("src/resources/path2.png"));
			boardTileImages[3] = ImageIO.read(new File("src/resources/path3.png"));
			boardTileImages[4] = ImageIO.read(new File("src/resources/path4.png"));
			boardTileImages[5] = ImageIO.read(new File("src/resources/path5.png"));
			boardTileImages[6] = ImageIO.read(new File("src/resources/path6.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/*
	 * So we can load a new level without creating a new GameBackground object
	 */
	public void load(String filename){
		
		String boardStr = loadString(filename);
		
		for(int i=0; i<vertical_squares; i++){
			String row = boardStr.split("-")[i];
			for(int j=0; j<horizontal_squares; j++){
				squares[j][i] = Character.getNumericValue(row.charAt(j));
			}
		}
		
		
	}
	
	private String loadString(String filename){
		try {
			BufferedReader br = new BufferedReader(new FileReader(filename));

		    String line = br.readLine();
		    String all = "";

		    while (line != null) {
		        all += line + "-";
		        line = br.readLine();
		    }
		    
		    br.close();
			return all;

		} catch (Exception e) {
			e.printStackTrace();
			return "";
		} 
		
	}

	/*
	 * Use the regular Java way of painting rather than a whole bunch of different GImages
	 * copies, which would be too slow.
	 */
	public void paint(Graphics g) {
		super.paint(g);
		
		for(int x=0; x < horizontal_squares; x++){
			for(int y=0; y < vertical_squares; y++){
				g.drawImage(boardTileImages[squares[x][y]], x*square_size, y*square_size, null);
			}
		}
	}
	
	public int getSquareValue(Point pt){
		if(pt.x < horizontal_squares && pt.y < vertical_squares){
			return squares[pt.x][pt.y];
		}else{
			return 0;
		}
	}

}