import java.awt.Point;
import acm.graphics.GImage;


//IMAGE FROM (there are others of similar style by that user):
//http://opengameart.org/content/bevouliin-free-enemy-villain-monster-game-asset-for-game-developers

public class Enemy extends GImage{

	private static int Y_OFFSET = -9;
	private int currImage; //will be either 0 or 1 for which image to display
	private double moveDistance = 2.5; // there will be 10 moves per square
	private int numMovesTracker = 0; //keeps track of how many moves for the given square
	private Point currSquare; //keeps track of what square we are on
	private String moveDir;
	
	public Enemy(){
		
		super("src/resources/enemyFrame1.png", -25, 5*25 + Y_OFFSET);

		currSquare = new Point(-1, 5);

		currImage = 0; 
		
		moveDir = "right";
		
	}
	
	
	public void move(){
		
		moveCorrectDirection();

		//switch the image 2 times per square
		if(numMovesTracker == 2 || numMovesTracker == 7){
			switchImageFrame();
		}
		
		
		numMovesTracker++;
		if(numMovesTracker == 10){
			setNextMoveDirection();
			
			numMovesTracker = 0;
		}
		
	}
	
	
	private void switchImageFrame(){
		
		if(currImage == 0){
			currImage++;
			setImage("src/resources/enemyFrame2.png");
		}else{
			currImage = 0;
			setImage("src/resources/enemyFrame1.png");
		}
	}
	
	private void setNextMoveDirection(){
		//set the next square
		if(moveDir == "right"){
			currSquare = new Point(currSquare.x + 1, currSquare.y);
		}else if(moveDir == "left"){
			currSquare = new Point(currSquare.x - 1, currSquare.y);
		}else if(moveDir == "up"){
			currSquare = new Point(currSquare.x, currSquare.y - 1);
		}else{
			currSquare = new Point(currSquare.x, currSquare.y + 1);
		}
		
		//INCOMPLETE
		//have to program all the different possible switches
		int newSquareValue = TowerDefense.game.getMap().getSquareValue(currSquare);
		if(moveDir == "right" && newSquareValue == 5){
			moveDir = "down";
		}
		if(moveDir == "down" && newSquareValue == 3){
			moveDir = "right";
		}
		
	}
	
	private void moveCorrectDirection(){
		
		if(moveDir == "right"){
			move(moveDistance,0);
		}else if(moveDir == "left"){
			move(-moveDistance,0);
		}else if(moveDir == "up"){
			move(0,-moveDistance);
		}else{
			move(0,moveDistance);
		}
	}


}