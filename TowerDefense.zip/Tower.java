import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import acm.graphics.GImage;
import acm.graphics.GRect;



public class Tower extends GImage{

	private static int Y_OFFSET = -11;
	private int numTryShootTracker = 0;
	private int shotFreq = 50;
	
	public Tower(int tile_x, int tile_y){
		
		super("src/resources/tower1.png", tile_x*TowerDefense.TILE_SIZE, tile_y*TowerDefense.TILE_SIZE + Y_OFFSET);
		
	}

	public void tryShoot(ArrayList<Enemy> enemies) {

		numTryShootTracker++;
		//only should shoot every once in a while
		if(numTryShootTracker == shotFreq){
			shootAtNearestEnemy(enemies);
			
			numTryShootTracker = 0;
		}
		
	}
	
	//could improve to only shoot at enemies within range
	private void shootAtNearestEnemy(ArrayList<Enemy> enemies){
		
		//INCOMPLETE
		//just shoots at first enemy for now
		Bullet bt =  new Bullet(this, enemies.get(0));
		TowerDefense.game.addBullet(bt);
		
	}

}