import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.LinkedList;
import java.util.Random;
import javax.swing.JFrame;
import javax.swing.WindowConstants;

public class Snake extends JFrame implements KeyListener {

	int boardPieces[][];
	int title_bar_height = 23;
	int squares_wide = 14;
	int squares_high = 12;
	int pixel_width = 700;
	int pixel_height = 600;
	int label_height = 25;
	int PAUSE_TIME = 333;

	private LinkedList<Point> snake;
	private String direction = "East";
	private String lastDirection = "East";
	private boolean gameOver = false;
	private Point apple;
	private Random rgen = new Random();
	private int score = 0;

	GameBoard gb;

	public static void main(String[] args) {  
		new Snake();  
	}

	public Snake(){  
		//set up our game variables
		boardPieces = new int[squares_wide][squares_high];
		setup();
		snakeToGrid();

		gb = new GameBoard(pixel_width, pixel_height, squares_wide, squares_high, boardPieces);
		add(gb);
		
		//set a few things for our JFrame
		setSize(pixel_width, pixel_height + title_bar_height + label_height);  
		setVisible(true);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		addKeyListener(this);

		//Keeps the game going as long as the game isn't over
		while(!gameOver) playGame();

		gb.setLabel("GAME OVER");
		this.repaint();

	} 

	//Switches direction of the snake depending on the key pressed
	public void keyPressed(KeyEvent e) {
		//Left Arrow Key
		if(e.getKeyCode() == 37 && !lastDirection.equals("East")) {
			direction = "West";
		} else if(e.getKeyCode() == 38 && !lastDirection.equals("South")) { //Up Arrow Key
			direction = "North";
		} else if(e.getKeyCode() == 39 && !lastDirection.equals("West")) { //Right Arrow Key
			direction = "East";
		} else if(e.getKeyCode() == 40 && !lastDirection.equals("North")) { //Down Arrow Key
			direction = "South";
		}
	}

	//Sets up the game by making the Snake as a LinkedList of points, and generating the apple
	private void setup(){
		snake = new LinkedList<Point>();
		snake.add(new Point(5, 6));
		snake.add(new Point(4, 6));
		snake.add(new Point(3, 6));

		generateApple();
	}

	//Generates the apple at a random location
	private void generateApple() {
		apple = new Point(rgen.nextInt(squares_wide), rgen.nextInt(squares_high));

		//If the location generated overlaps with the existing body of the snake, 
		while(isInvalidLocation()) {			         //regenerate somewhere else
			apple = new Point(rgen.nextInt(squares_wide), rgen.nextInt(squares_high));
		}
	}

	//Returns whether or not the apple overlaps with any part of the snake
	private boolean isInvalidLocation() {
		for(int i = 0; i < snake.size(); i++) {
			if (apple.x == snake.get(i).x && apple.y == snake.get(i).y) {
				return true;
			}
		}
		return false;
	}

	//Clears the board
	private void clear() {
		for(int i = 0; i < boardPieces[0].length; i++) {
			for(int j = 0; j < boardPieces.length; j++) {
				boardPieces[j][i] = 0;
			}
		}
		
		//add the apple back
		boardPieces[apple.x][apple.y] = 2;
	}

	//Converts the Snake (LinkedList of Points) to a 2D array for displaying 
	//on the screen.
	private void snakeToGrid() {
		if(!gameOver) {
			clear();
		
			for(int i = 0; i < snake.size(); i++) {
				boardPieces[snake.get(i).x][snake.get(i).y] = 1;
			}
		}
	}

	//Plays the game
	private void playGame() {
		
		moveSnakeCheckApple();
		checkBounds();
		checkOverlap();
		if(!gameOver) snakeToGrid();
		gb.setLabel("Score: " + score);
		this.repaint();
		pause(PAUSE_TIME);
		
	}



	private void checkBounds() {
		if(snake.getFirst().x < 0 || snake.getFirst().x == squares_wide || 
				snake.getFirst().y < 0 || snake.getFirst().y ==squares_high) {
			gameOver = true;
		}
	}

	//Moves the snake by moving the head one square in it's proper direction, and moving every
	//part of the snake besides the head to the position of the Point before it
	private void moveSnakeCheckApple() {
		//remember the direction of this move and the head for later
		lastDirection = direction;
		Point oldLocation = snake.getFirst();

		if(direction.equals("North")) {
			snake.set(0, new Point(snake.getFirst().x, snake.getFirst().y - 1)); //Sets the head of the snake to be one cell
		} else if (direction.equals("East")) {								  //over in the 2D array
			snake.set(0, new Point(snake.getFirst().x + 1, snake.getFirst().y)); //Sets the head of the snake to be one cell
		} else if (direction.equals("West")) { 								   //over in the 2D array
			snake.set(0, new Point(snake.getFirst().x - 1, snake.getFirst().y)); //Sets the head of the snake to be one cell
		} else {											  					  //over in the 2D array
			snake.set(0, new Point(snake.getFirst().x, snake.getFirst().y + 1)); //Sets the head of the snake to be one cell 
		}																	  //over in the 2D array

		//Sets every segment in the body of the snake to be the location of the segment before it
		for(int i = 1; i < snake.size(); i++) {
			Point tempLocation = snake.get(i);
			snake.set(i, oldLocation);
			oldLocation = tempLocation;
		}
		
		if(snake.getFirst().equals(apple)) {
			generateApple();
			snake.add(oldLocation);
			score++;
		} 
		
		
	}

	//Pauses for i milliseconds
	private void pause(int i) {
		try { 
			Thread.sleep(i); 
		} catch (InterruptedException e) { 

		}
	}

	//Checks whether or not the snake's head overlaps with any segment of it's body
	private void checkOverlap() {
		if(snake.lastIndexOf(snake.getFirst()) != 0) gameOver = true;
	}

	public void keyTyped(KeyEvent e) {}
	public void keyReleased(KeyEvent e) {}
}