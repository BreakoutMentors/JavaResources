/**
 * JuiceMind runs the class called Main, so this just launches the real game.
 * All the actual code lives in PacmanGame.java, Pacman.java and Board.java.
 */
public class Main {
    public static void main(String[] args) {
        new PacmanGame().start(args);
    }
}
