import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.WindowConstants;

public class GameOfLife extends JFrame implements MouseListener {	

	int boardPieces[][];
	int title_bar_height = 23;
	int squares_per_side = 32;
	int pixels_per_side = 800;
	int label_height = 25;
	int pauseMilliSec = 500;
	boolean isRunning = false;
	int numSteps = 0;
	
	//Number of pixels wide the square is
	private int sq_pixels = pixels_per_side / squares_per_side;
	GameBoard gb;
	
	JButton startPauseBtn;

	public static void main(String[] args) {  
		new GameOfLife();  
	}
	
	public GameOfLife(){  
		
		//set up our game variables
		boardPieces = new int[squares_per_side][squares_per_side];
		
		JButton clrBtn = new JButton("Clear");
		clrBtn.setBounds(pixels_per_side-90, pixels_per_side-1, 80, 30);
		clrBtn.addActionListener(new ActionListener() { 
			  public void actionPerformed(ActionEvent e) { 
				  clearBoard();
			  }
		});
		add(clrBtn);
		
		startPauseBtn = new JButton("Start");
		startPauseBtn.setBounds(10, pixels_per_side-1, 80, 30);
		startPauseBtn.addActionListener(new ActionListener() { 
			  public void actionPerformed(ActionEvent e) { 
				  startPausePressed();
			  }
		});
		add(startPauseBtn);
				
		gb = new GameBoard(pixels_per_side, squares_per_side, boardPieces);
		gb.setLabel("Set starting state");
		add(gb);
			
		//set a few things for our JFrame
		setSize(pixels_per_side, pixels_per_side + title_bar_height + label_height);  
		setVisible(true);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		addMouseListener(this);
		
		
		while(true){
			try {
				Thread.sleep(pauseMilliSec);
				
				if(isRunning){
					doStep();
				}
				
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
	} 
	
	//    Any live cell with fewer than two live neighbours dies, as if by underpopulation.
	//    Any live cell with two or three live neighbours lives on to the next generation.
	//    Any live cell with more than three live neighbours dies, as if by overpopulation.
	//    Any dead cell with exactly three live neighbours becomes a live cell, as if by reproduction.
	private void doStep(){
		
		//start a blank  board
		int[][] newBoard = new int[squares_per_side][squares_per_side];
		
		for(int i=0; i<squares_per_side; i++){
			for(int j=0; j<squares_per_side; j++){
				
				boolean isAlive = boardPieces[i][j] == 1;
				int numNeighbors = countNeighbors(i, j);
				
				if(isAlive){
					if(numNeighbors == 2 || numNeighbors == 3) newBoard[i][j] = 1;
				}else{
					if(numNeighbors == 3) newBoard[i][j] = 1;
				}
				
			}
		}
		
		numSteps++;
		gb.setLabel("Steps: " + numSteps);
				
		gb.setBoard(newBoard);
		boardPieces = newBoard;
		this.repaint();
	}
	
	//needs to look at all the neighbors, but have to be careful to not go out of 2D array bounds
	//it should wrap around to check the other side
	private int countNeighbors(int row, int col){
		int numNeighbors = 0;
		
		//check for all 4 edges
		int rowMinus = row - 1;
		if(rowMinus < 0) rowMinus = squares_per_side-1;
		
		int rowPlus = row + 1;
		if(rowPlus > squares_per_side-1) rowPlus = 0;
		
		int colMinus = col - 1;
		if(colMinus < 0) colMinus = squares_per_side-1;
		
		int colPlus = col + 1;
		if(colPlus > squares_per_side-1) colPlus = 0;
		
		
		//then check all 8 positions
		if(boardPieces[rowMinus][col] == 1) numNeighbors++;
		if(boardPieces[rowPlus][col] == 1) numNeighbors++;
		if(boardPieces[row][colMinus] == 1) numNeighbors++;
		if(boardPieces[row][colPlus] == 1) numNeighbors++;
		if(boardPieces[rowMinus][colMinus] == 1) numNeighbors++;
		if(boardPieces[rowMinus][colPlus] == 1) numNeighbors++;
		if(boardPieces[rowPlus][colMinus] == 1) numNeighbors++;
		if(boardPieces[rowPlus][colPlus] == 1) numNeighbors++;
		
		return numNeighbors;
	}

	public void mouseClicked(MouseEvent e) {
		//Does Integer Division by the size of a square in order to get the number square
		//(i.e. the top leftmost square is square (0, 0), bottom rightmost square is square(7,7)
		
		//getInsets() asks the window how tall its title bar actually is. It is a
		//different size on Mac, Windows, and Linux, so we can't hard-code it.
		java.awt.Insets insets = getInsets();
		int clickedX = (e.getX() - insets.left) / sq_pixels;
		int clickedY = (e.getY() - insets.top) / sq_pixels;

		//ignore clicks outside the grid (like on the buttons along the bottom)
		if(clickedX < 0 || clickedX >= squares_per_side || clickedY < 0 || clickedY >= squares_per_side){
			return;
		}

		if(boardPieces[clickedX][clickedY] == 0){
			boardPieces[clickedX][clickedY] = 1;
		}else{
			boardPieces[clickedX][clickedY] = 0;
		}
		
		this.repaint();

	}
	
	private void clearBoard(){
		numSteps = 0;
		gb.setLabel("Set starting state");
		
		boardPieces = new int[squares_per_side][squares_per_side];
		gb.setBoard(boardPieces);
		this.repaint();
	}

	private void startPausePressed(){
		isRunning = !isRunning;

		if(isRunning){
			startPauseBtn.setText("Pause");
		}else{
			startPauseBtn.setText("Start");
		}
		
	}
	

	
	
	/* not using the following mouse listener methods, but need these here */
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
	}
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub		
	}
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub	
	}
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub	
	}


}
