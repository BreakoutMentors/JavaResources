import acm.graphics.GImage;

public class EnemyShip extends GImage {

	double SPEED = -1;
	
	public EnemyShip(int x, int y, double scale){
		super("spaceship.png", x, y);
		scale(.08*scale);
	}

	public void moveShip(){
		move(SPEED,0);
	
		//IMPROVE THIS SO THE ENEMIES BOUNCE OFF THE SIDE AND GO BACK THE OTHER WAY
	}

}