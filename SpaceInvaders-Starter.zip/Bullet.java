import java.awt.Color;
import acm.graphics.GOval;


public class Bullet extends GOval {
	
	private static final int BULLET_DIAM = 5;
	private static final int BULLET_SPEED = 8;
	
	public Bullet(double spaceshipX, double spaceshipY){
		
		super(spaceshipX, spaceshipY, BULLET_DIAM, BULLET_DIAM);
		setFilled(true);
		setColor(Color.WHITE);
		
	}

	public void moveUp(){	
		
		move(0, -BULLET_SPEED);
		
	}
	
	
	
}