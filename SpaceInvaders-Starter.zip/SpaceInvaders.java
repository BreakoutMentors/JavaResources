import acm.program.*;
import acm.util.RandomGenerator;
import acm.graphics.*;

import java.awt.Color;
import java.awt.event.*;
import java.util.ArrayList;


public class SpaceInvaders extends GraphicsProgram {

	public static final int APPLICATION_WIDTH = 800;
	public static final int APPLICATION_HEIGHT = 700;

	private static final int DELAY = 10;
	private ArrayList<Bullet> bullets = new ArrayList<Bullet>();
	private ArrayList<EnemyShip> enemies = new ArrayList<EnemyShip>();

	private GImage player;

	private int ENEMIES_PER_ROW = 8;
	private int ENEMY_ROWS = 2;
	private int ENEMY_SEP_X = 15;
	private int ENEMY_SEP_Y = 100;


	private RandomGenerator rgen = RandomGenerator.getInstance();


	public void run(){

		setup();

		while (true) {

			moveEverything();
			checkForCollisions();
			pause(DELAY);

		}

	}

	private void setup() {
		
		setBackground(Color.BLACK);

		//create your spaceship
		player = new GImage("myspaceship.png", 400, 620);
		add(player);

		//create all the enemies
		//IMPROVE THIS SECTION SO YOU CREATE ROWS OF ENEMIES
		EnemyShip enemy = new EnemyShip(200, 120, 1);
		add(enemy);
		enemies.add(enemy);

		//add the mouse listeners
		addMouseListeners();
	}

	private void moveEverything(){
		//move the bullets
		for(int i=0; i<bullets.size(); i++){
			Bullet currentBullet = bullets.get(i);
			currentBullet.moveUp();

			//if the bullet is off the screen, remove it
			if(currentBullet.getY() <= 0){
				bullets.remove(currentBullet);
				remove(currentBullet);
			}
		}

		//move the enemies
		for(int j=0; j<enemies.size(); j++){
			EnemyShip currentEnemy = enemies.get(j);
			currentEnemy.moveShip();
		}

		//ADD ENEMY BULLET MOVEMENT HERE

	}


	public void mouseClicked(MouseEvent e) {

		//create a new bullet object
		Bullet newBullet = new Bullet(player.getX() + player.getWidth()/2, player.getY());

		//add it to the screen
		add(newBullet);

		//add it to our arraylist so we can track it
		bullets.add(newBullet);
	}

	private void checkForCollisions() {

		//check each bullet to see if it hit any enemy
		for(int i=0; i<bullets.size(); i++){

			Bullet currentBullet = bullets.get(i);
			GObject collObj = getElementAt(currentBullet.getX(), currentBullet.getY());

			if(collObj != null && collObj != player){
				//remove the enemy spaceship and the bullet
					
					enemies.remove(collObj);
					remove(collObj);

					bullets.remove(currentBullet);
					remove(currentBullet);
			}
		}

		//ADD CHECK TO SEE IF ENEMY BULLETS HIT YOU HERE
	}



}