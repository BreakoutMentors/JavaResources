import java.util.ArrayList;



public class Square {
	
	private ArrayList<Integer> possibleValues = new ArrayList<Integer>();
	
	public Square(Integer i){
		
		if(i.intValue() != 0){
			//square is solved so only possible value is i
			possibleValues.add(i);
		}else{
			//0 means don't know the value of square yet so all are possible
			for(int j=1; j<10; j++){
				possibleValues.add(j);
			}
		}
		
	}
	
	
	
	public boolean isSolved(){
		if(possibleValues.size() == 1){
			return true;
		}else{
			return false;
		}
	}
	
	@Override public String toString(){
		
		if(isSolved()){
			return possibleValues.get(0).toString();
		}else{
			String str = "{";
			for(int i=0; i<possibleValues.size(); i++){
				str += possibleValues.get(i).toString();
			}
			return str+"}";
			
		}
		
		
	}
	
	
}