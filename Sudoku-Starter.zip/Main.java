/**
 * JuiceMind runs the class called Main, so this just launches the real program.
 * All the actual code lives in SudokuSolver.java (and Board / Square / BoardLoader).
 */
public class Main {
    public static void main(String[] args) {
        new SudokuSolver().start(args);
    }
}
