import acm.program.GraphicsProgram;



public class Board extends GraphicsProgram{
	
	private Square[][] board;
	
	public Board(Square[][] start){
		
		board = start;
		
		//add other ways of storing the information for playing the game
		//what is more helpful than a 2-D array?
		
	}
	
	
	public boolean isSolved(){
		//complete this
		
		return false;
	}
	
	public void onePass(){
		//process some changes
	}
	
	public Square[][] getBoard(){
		return board;
	}
	
}