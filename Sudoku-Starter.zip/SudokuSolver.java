import java.awt.Color;
import java.awt.Font;

import acm.graphics.GLabel;
import acm.graphics.GLine;
import acm.program.GraphicsProgram;



public class SudokuSolver extends GraphicsProgram{
	
	private int size = 750;
	
	public void run(){
		
		setSize(size,size+50);
		
		Board board = BoardLoader.load("boards/board1.txt");
		
		while(board.isSolved() == false){
			
			display(board);
			
			pause(1000);

			board.onePass();
			
		}
		
		
	}
	
	public void display(Board board){
		
		//clear everything
		removeAll();
		
		//add the 4 lines
		add(new GLine(size/3, 0, size/3, size));
		add(new GLine(size*2/3, 0, size*2/3, size));
		add(new GLine(0, size/3, size, size/3));
		add(new GLine(0, size*2/3, size, size*2/3));
		
		for(int i=0; i<9; i++){
			for(int j=0; j<9; j++){
			
				Square sq = board.getBoard()[i][j];
				String value = sq.toString();
				GLabel label = new GLabel(value, 25 + i*size/9, 40+ j*size/9);
				if(value.length() > 1){
					label.setFont(new Font("SansSerif", Font.ITALIC, 8));
				}
				add(label);
			}
		}
		
		
	}
	
	
	
}