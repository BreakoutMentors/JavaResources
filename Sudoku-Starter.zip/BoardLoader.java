import java.io.BufferedReader;
import java.io.FileReader;

//This class if finished and is used to read in a board from a text file
//A 0 represents a space that is not known at the start

public class BoardLoader {
	
	
	public static Board load(String filename){
		
		String boardStr = loadString(filename);
		Square[][] board = new Square[9][9];
		
		//create all the squares
		for(int i=0; i<9; i++){
			String row = boardStr.split("-")[i];
			for(int j=0; j<row.length(); j++){
				Square sq = new Square(Character.getNumericValue(row.charAt(j)));
				board[j][i] = sq;
			}
			
		}
		
		return new Board(board);
	}
	
	
	//reads in the board as one string with a separator
	private static String loadString(String filename){
		try {
			BufferedReader br = new BufferedReader(new FileReader(filename));

		    String line = br.readLine();
		    String all = "";

		    while (line != null) {
		        all += line + "-";
		        line = br.readLine();
		    }
		    
		    br.close();
			return all;

		} catch (Exception e) {
			e.printStackTrace();
			return "";
		} 
		
	}
	
}