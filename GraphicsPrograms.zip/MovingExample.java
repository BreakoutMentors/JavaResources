import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;

public class MovingExample extends GraphicsProgram {	

	private int speed = 1;
	private int maxSpeed = 20;
	private int speedIncrease = 2;
	private int pauseLength = 10;

	public void run() {

		//create the circle
		GOval circle = new GOval(0,250,20,20);
		circle.setFilled(true);
		add(circle);

		boolean movingRight = true;

		//infinite loop
		while(true){
			
			if(movingRight == true){
				circle.move(speed, 0);
				
				//check if it hit the right wall
				double circleX = circle.getX();
				if(circleX >= getWidth() - circle.getWidth()){
					movingRight = false;
					increaseSpeed();
				}
			}else{
				circle.move(-speed,0);
				
				//check if it hit the left wall
				double circleX = circle.getX();
				if(circleX <= 0){
					movingRight = true;
					increaseSpeed();
				}
			}
			
			pause(pauseLength);

		}
		
		
		
	}
	
	
	public void increaseSpeed(){
		speed = speed + speedIncrease;
		if(speed > maxSpeed){
			speed = maxSpeed;
		}
	}


}
