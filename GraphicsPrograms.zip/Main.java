/**
 * JuiceMind always runs the class called Main, so this file is the switchboard:
 * exactly ONE line below is uncommented, and that's the program that runs.
 *
 * To try a different one, put // in front of the line that's currently on, take
 * the // off the one you want, and press Run.
 *
 * The EXAMPLES are finished programs — run them, then read them for ideas.
 * The YOUR TURN programs are the ones with work left to do.
 */
public class Main {
    public static void main(String[] args) {

        // ---- EXAMPLES (already finished) -----------------------------------
        new RobotFace().start(args);
        //new Checkerboard().start(args);
        //new Pyramid().start(args);
        //new ColorChangingSquare().start(args);
        //new MovingExample().start(args);
        //new RandomArtFinished().start(args);
        //new RecursiveSquareDrawing().start(args);

        // ---- YOUR TURN -----------------------------------------------------
        //new Target().start(args);
        //new RowOfBricks().start(args);
        //new RandomArt().start(args);
        //new AnimationPatternMatching().start(args);
    }
}
