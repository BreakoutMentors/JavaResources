import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;
import java.awt.*;

public class RecursiveSquareDrawing extends GraphicsProgram {	


	private RandomGenerator rgen = RandomGenerator.getInstance();
	
	int size = 800;
	int pauseLength = 100;
	
	public void run() {		
		setSize(size+1, size+23); //slightly bigger to account for title bar
		
		drawSquares(7, 0, 0, size, rgen.nextColor());
	}
	
	
	private void drawSquares(int depth, int x, int y, int size, Color myColor){
		
		if(depth == 0){
			return;
		}else{
			pause(pauseLength);

			//colored rect 1
			GRect rectangle = new GRect(x,y,size/2,size/2);
			rectangle.setFilled(true);
			rectangle.setFillColor(myColor);
			add(rectangle);
			
			//colored rect 2
			GRect rectangle2 = new GRect(x + size/2, y + size/2,size/2,size/2);
			rectangle2.setFilled(true);
			rectangle2.setFillColor(myColor);
			add(rectangle2);
			
			//white rect 1
			GRect rectangle3 = new GRect(x + size/2, y,size/2,size/2);
			rectangle3.setFilled(true);
			rectangle3.setFillColor(Color.white);
			add(rectangle3);
			
			//white rect 2
			GRect rectangle4 = new GRect(x, y+size/2,size/2,size/2);
			rectangle4.setFilled(true);
			rectangle4.setFillColor(Color.white);
			add(rectangle4);
			
			Color myColor2 =  rgen.nextColor();
			//recursively call to add new squares half the size
			drawSquares(depth - 1, x, y + size/2, size/2, myColor2);
			drawSquares(depth - 1, x + size/2, y, size/2, myColor2);
			
		}
		
	}
	

	
	
}
