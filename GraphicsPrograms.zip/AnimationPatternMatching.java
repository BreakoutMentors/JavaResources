import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;

public class AnimationPatternMatching extends GraphicsProgram {	
	
	/*BEFORE YOU BEGIN:
	 *-----------------
	 *Run the program and read through the code below.
	 *This is a pattern matching project, so you don't have
	 *to understand the code completely in order to do the
	 *challenge - you are given working code and can play around
	 *with it to understand how it works, what lines you will need
	 *to copy to complete the challenge, and how you need to modify
	 *those lines.
	 */
	
	/*YOUR CHALLENGE:
	 *---------------
	 *Add a square that travels up and down, bouncing off
	 *the top and bottom of the screen.
	 *See the steps at the bottom if you need a hint.
	 */

	//set up the variables
	private int pauseLength = 20;
	private int circleSpeed = 5;

	public void run() {

		//add the circle to the screen
		GOval circle = new GOval(100,250,20,20);
		circle.setFilled(true);
		add(circle);

		//keep running the animation forever
		while(true){
			
			circle.move(circleSpeed, 0);
			
			double circleX = circle.getX();
				
			//check if hits the right side
			if(circleX >= 734){
				circleSpeed = -circleSpeed;
			}
			
			//check if hits the left side
			if(circleX <= 0){
				circleSpeed = -circleSpeed;
			}
			
			pause(pauseLength);

		}
		
	}
	
	//Note: 734 = getWidth() - circle.getWidth()

}

/*STEPS:
 *------
 * 1. How do you add a square to the screen?
 * 2. What variables do you need to create?
 * 3. How do you make the square move?
 * 4. How do you make the square bounce off the bottom side?
 * 5. How do you make the square bounce off the top side?
 */
