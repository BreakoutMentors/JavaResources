
import acm.graphics.*;
import acm.program.*;
import java.awt.*;

public class RowOfBricks extends GraphicsProgram {	

	int brickHeight = 30;
	int brickWidth = 15;
	int numberOfBricks = 18;
	
	//Use the variables above to create a whole row of bricks, one after the other
	//Hint: what loop will you use?
	
	public void run() {

		//your code here
		
	}
}
