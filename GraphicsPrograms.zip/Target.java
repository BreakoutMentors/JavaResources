/*
 * File: Target.java
 * Name: 
 * Section Leader: 
 * -----------------
 * This file is the starter file for the Target problem.
 */

import acm.graphics.*;
import acm.program.*;
import java.awt.*;

public class Target extends GraphicsProgram {	
	
	//center a target on the page
	
	//add a big label
	
	public void run() {
	
		/* You fill this in. */
		
		
	}
}
