import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;
import java.awt.*;


public class RandomArt extends GraphicsProgram {	

	private RandomGenerator rgen = RandomGenerator.getInstance();

	//Step 0: create a circle on the screen
	//Step 1: make the circle have a random location
	//Step 2: make the circle have a random size
	//Step 3: make the circle have a random color
	//Step 4: half the time make it a circle, half the time a square
	//Step 5: do it 1000 times
	//Step 6: pause 1/50th a second between each shape
	//Step 7: what would make it look cooler?

	public void run() {

		//your code here
		
	}
	
	
}
