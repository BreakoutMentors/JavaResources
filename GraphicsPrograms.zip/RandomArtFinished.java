import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;
import java.awt.*;


public class RandomArtFinished extends GraphicsProgram {	

	private RandomGenerator rgen = RandomGenerator.getInstance();


	public void run() {
		
		for(int i=0; i<10000; i++){

			int randomLocationX = rgen.nextInt(0, getWidth());
			int randomLocationY = rgen.nextInt(0, getHeight());
			int randomSize = rgen.nextInt(10,25);
			Color randomColor = rgen.nextColor();
			
			int randomShape = rgen.nextInt(0,100);
			
			if(randomShape > 50){
				GRect square = new GRect(randomLocationX, randomLocationY, randomSize, randomSize);
				add(square);
				
				square.setFilled(true);
				square.setFillColor(randomColor);
				square.setColor(randomColor);
			}else{
				GOval circle = new GOval(randomLocationX, randomLocationY, randomSize, randomSize);
				add(circle);
				
				circle.setFilled(true);
				circle.setFillColor(randomColor);
				circle.setColor(randomColor);
			}	
			
			pause(20);
		}
		
	}
	
	
}
