/*
 * File: Pyramid.java
 * Name: 
 * Section Leader: 
 * ------------------
 * This file is the starter file for the Pyramid problem.
 * It includes definitions of the constants that match the
 * sample run in the assignment, but you should make sure
 * that changing these values causes the generated display
 * to change accordingly.
 */

import acm.graphics.*;
import acm.program.*;
import java.awt.*;

public class Pyramid extends GraphicsProgram {

/** Width of each brick in pixels */
	private static final int BRICK_WIDTH = 30;

/** Width of each brick in pixels */
	private static final int BRICK_HEIGHT = 12;

/** Number of bricks in the base of the pyramid */
	private static final int BRICKS_IN_BASE = 20;
	
	public void run() {
		
		int baseWidth = BRICK_WIDTH * BRICKS_IN_BASE;
		int startingSpotX = (getWidth() - baseWidth)/2;
		int startingSpotY = 400;
		
		//for each stack of bricks
		for(int y=0; y<BRICKS_IN_BASE; y++){
			
			//each row has 1 less brick
			int bricksInRow = BRICKS_IN_BASE - y;
			
			//for each brick in the row
			for(int x=0; x<bricksInRow; x++){
				//x position of brick is the starting spot, moved over a brick length each time
				//and offset by half a brick each stack up
				int xPosition = startingSpotX + x*BRICK_WIDTH + y*BRICK_WIDTH/2;
				//y position of the brick is the starting spot, moved up a brick height each stack up
				int yPosition = startingSpotY - y*BRICK_HEIGHT;
				
				GRect brick = new GRect(xPosition,yPosition,BRICK_WIDTH,BRICK_HEIGHT);
				add(brick);
				
			}
			
		}
		
		
	}
}

