import acm.graphics.*;
import java.awt.*;
import acm.program.*;
import acm.util.*;
import java.awt.event.*;
import java.util.ArrayList;
import acm.util.MediaTools;
import javax.swing.SwingUtilities;

public class Memory extends GraphicsProgram {

	/* The 6x4 grid of cards needs 725 x 500 pixels, so ask for a window that fits it.
	 * Without these two constants ACM picks its default size and clips the bottom row. */
	public static final int APPLICATION_WIDTH = 760;
	public static final int APPLICATION_HEIGHT = 520;

	boolean match = false;
	boolean bob = true;
	GRect button1;
	GRect button2;
	String[][] a = new String[4][6];
	ArrayList<String> imageNames = new ArrayList<String>();
	RandomGenerator rgen = RandomGenerator.getInstance();
	String card1;
	String card2;
	public GObject obj1;
	public GObject obj2;
	GImage[]images = new GImage[24];
	boolean firstCard =true;
	GRect titleScreen;
	GLabel title;
	GLabel buttonName;
	GLabel buttonName2;

	public void run(){
		addMouseListeners();
		titleScreen = new GRect(0, 0, getWidth(), getHeight());
		titleScreen.setFilled(true);
		titleScreen.setFillColor(Color.DARK_GRAY);
		title = new GLabel("Memory Game");
		title.setFont(new Font("Arial", Font.BOLD, 48));
		title.setColor(Color.GREEN);
		title.setLocation(getWidth()/2-title.getWidth()/2, getHeight()/2+title.getHeight()/2);
		add(titleScreen);
		add(title);
		button1 = new GRect(235, 300, 300, 75);
		button1.setFillColor(Color.GREEN);
		button1.setFilled(true);
		buttonName = new GLabel("Shapes");
		buttonName.setFont(new Font("Arial", Font.BOLD, 34));
		buttonName.setLocation(button1.getX()+button1.getWidth()/2-buttonName.getWidth()/2, button1.getY()+button1.getHeight()/2+buttonName.getHeight()/2-10);
		add(button1);
		add(buttonName);
		button2 = new GRect(235,400,300, 75);
		button2.setFillColor(Color.GREEN);
		button2.setFilled(true);
		buttonName2 = new GLabel("Patterns");
		buttonName2.setFont(new Font("Arial", Font.BOLD, 34));
		buttonName2.setLocation(button2.getX()+button2.getWidth()/2-buttonName2.getWidth()/2, button2.getY()+button2.getHeight()/2+buttonName2.getHeight()/2-10);
		add(button2);
		add(buttonName2);
	}

	public void mouseClicked(MouseEvent e){
		if(bob == true){
			//the caption sits on top of the button, so asking "what did I click?" returns
			//the text, not the button. Ask each button whether the point is inside it instead.
			if(button1.contains(e.getX(), e.getY())){
				imageNames.add("shape-circle.png");
				imageNames.add("shape-circle.png");
				imageNames.add("shape-square.png");
				imageNames.add("shape-square.png");
				imageNames.add("shape-triangle.png");
				imageNames.add("shape-triangle.png");
				imageNames.add("shape-star.png");
				imageNames.add("shape-star.png");
				imageNames.add("shape-diamond.png");
				imageNames.add("shape-diamond.png");
				imageNames.add("shape-hexagon.png");
				imageNames.add("shape-hexagon.png");
				imageNames.add("shape-pentagon.png");
				imageNames.add("shape-pentagon.png");
				imageNames.add("shape-cross.png");
				imageNames.add("shape-cross.png");
				imageNames.add("shape-ring.png");
				imageNames.add("shape-ring.png");
				imageNames.add("shape-heart.png");
				imageNames.add("shape-heart.png");
				imageNames.add("shape-arrow.png");
				imageNames.add("shape-arrow.png");
				imageNames.add("shape-moon.png");
				imageNames.add("shape-moon.png");
				bob = false;
				startGame();
			}else if(button2.contains(e.getX(), e.getY())){
				imageNames.add("pat-stripes-red.png");
				imageNames.add("pat-stripes-red.png");
				imageNames.add("pat-stripes-blue.png");
				imageNames.add("pat-stripes-blue.png");
				imageNames.add("pat-dots-green.png");
				imageNames.add("pat-dots-green.png");
				imageNames.add("pat-dots-purple.png");
				imageNames.add("pat-dots-purple.png");
				imageNames.add("pat-checks-orange.png");
				imageNames.add("pat-checks-orange.png");
				imageNames.add("pat-checks-teal.png");
				imageNames.add("pat-checks-teal.png");
				imageNames.add("pat-bars-brown.png");
				imageNames.add("pat-bars-brown.png");
				imageNames.add("pat-bars-navy.png");
				imageNames.add("pat-bars-navy.png");
				imageNames.add("pat-grid-magenta.png");
				imageNames.add("pat-grid-magenta.png");
				imageNames.add("pat-grid-olive.png");
				imageNames.add("pat-grid-olive.png");
				imageNames.add("pat-zigzag-maroon.png");
				imageNames.add("pat-zigzag-maroon.png");
				imageNames.add("pat-zigzag-cyan.png");
				imageNames.add("pat-zigzag-cyan.png");
				bob = false;
				startGame();
			}
		}else{
			GObject clicked = getElementAt(e.getX(), e.getY());
			//only a face-down card (one of the magenta rectangles) can be flipped. This
			//also stops you clicking the same card twice, or clicking a pair you already
			//matched - in both of those cases what's under the mouse is a picture, not a card.
			if(clicked instanceof GRect){
				int row = (e.getX()-35)/115;
				int col = (e.getY()-20)/115;

				//the grid is 6 columns by 4 rows; ignore clicks that land outside it
				if(row < 0 || row > 5 || col < 0 || col > 3){ return; }
				if(firstCard){
					obj1 = clicked;
					remove(obj1);
					card1 = a[col][row];
					firstCard = false;
				}else{
					obj2 = clicked;
					remove(obj2);
					card2 = a[col][row];
					checkMatch(card1, card2);
					if(match){
					}
					else{
						SwingUtilities.invokeLater(new Runnable() {
							public void run() {
								pause(1000);
								add(obj1);
								add(obj2);
							}
						});
					}
					firstCard = true;
				}
			}
		}
	}

	private void checkMatch(String card1, String card2){
		if(card1.equals(card2)){
			match = true;
		}else{
			match = false;
		}
	}

	private void startGame() {
		int x = 0;
		for(int j = 0; j<4; j++){
			for(int i = 0; i<6; i++){
				int n = rgen.nextInt(imageNames.size());
				GImage image = new GImage(imageNames.get(n), 35+i*115, 20+j*115);
				a[j][i] = imageNames.get(n);
				imageNames.remove(n);
				image.setSize(100, 100);
				image.setVisible(false);
				images[x]= image;
				add(image);
				x++;
			}
		}

		pause(1000);
		remove(title);
		remove(button1);
		remove(button2);
		remove(buttonName);
		remove(buttonName2);
		remove(titleScreen);
		for(int j = 0; j<4; j++){
			for(int i = 0; i<6; i++){
				GRect card = new GRect(35+i*115, 20+j*115, 100, 100);
				add(card); 
				card.setFillColor(Color.MAGENTA);
				card.setFilled(true);
			}
		}
		for(GImage i: images){
			i.setVisible(true);
		}
	}
}