import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Image extends ScreenObject {

    private double x, y;
    private BufferedImage i;

    public Image(double x, double y, String filename){
      this.x = x;
      this.y = y;

      try{
        i = ImageIO.read(new File(filename));
      } catch (IOException e){
        System.err.println("Caught IOException: " +  e.getMessage());
      }
    }

    public void move(){
      this.y += 1;
    }

    public Rectangle getRectangle(){
      //this image is always 64x64
      return new Rectangle((int) x, (int) y, 64, 64);
    }

    public void paint(Graphics g) {

      g.drawImage(i, (int) x, (int) y, null);

    }
}
