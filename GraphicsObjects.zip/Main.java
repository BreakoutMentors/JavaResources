import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;
import java.awt.event.*;

public class Main extends Canvas {

    private ArrayList<ScreenObject> objects;
    private Image player; 

    public Main() {

      //create game
      objects = new ArrayList<ScreenObject>();
      Oval o = new Oval(180, 100);
      objects.add(o);
      Image i = new Image(300, 0, "myspaceship.png");
      objects.add(i);
      player = i;

      addMouseListener(new MouseListener(){
                    public void mouseClicked(MouseEvent e){
                        System.out.println("CLICKED: " + e.getX() + ", " + e.getY());
                    }
                    public void mouseEntered(MouseEvent arg0) {}
                    public void mouseExited(MouseEvent arg0) {}
                    public void mousePressed(MouseEvent arg0) {}
                    public void mouseReleased(MouseEvent arg0) {}
        });

      addKeyListener(new KeyListener(){
                    public void keyPressed(KeyEvent e){
                        System.out.println("PRESSED: " + e.getKeyCode());
                    }
                    public void keyReleased(KeyEvent e){}
                    public void keyTyped(KeyEvent e){}
        });

    addMouseMotionListener(new MouseMotionListener(){
                    public void mouseMoved(MouseEvent e){
                        System.out.println("MOVED: " + e.getX() + ", " + e.getY());
                    }
                    public void mouseDragged(MouseEvent e){}
      });
    
    }

    public static void main(String[] args) {
        JFrame f = new JFrame("Graphics");
        Main c = new Main();
        c.setSize(400, 400);
        f.add(c);
        f.pack();
        f.setVisible(true);

        c.gameLoop();
    }

    private void gameLoop(){
      //play game
      while(true){

        //move everything
        for(int i=0; i<objects.size(); i++){
          objects.get(i).move();
        }

        //decide any collisions

        //see if player hits any ovals
        for(int i=0; i<objects.size(); i++){
          ScreenObject obj = objects.get(i);
          if(obj instanceof Oval){
            boolean overlap = obj.getRectangle().intersects(player.getRectangle());
            if(overlap) System.out.println("HIT");
          }
        }

        repaint();

        try {
          //pause for 25 millisecs, can adjust if needed
          Thread.sleep(25);
        } catch(InterruptedException e) {
          //empty
        }
      }
    }

    public void paint(Graphics g) {

        //paint every object
        for(int i=0; i<objects.size(); i++){
          objects.get(i).paint(g);
        }
        
    }
}
