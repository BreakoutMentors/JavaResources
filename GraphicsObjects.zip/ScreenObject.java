import java.awt.*;

public abstract class ScreenObject {

    abstract Rectangle getRectangle();
    abstract void move();
    abstract void paint(Graphics g);
    
}
