import java.awt.*;

public class Oval extends ScreenObject {

    private double x, y;

    public Oval(double x, double y){
      this.x = x;
      this.y = y;
    }

    public void move(){
      this.x += 1;
    }

    public Rectangle getRectangle(){
      //the oval is always 30x40
      return new Rectangle((int) x, (int) y, 30, 40);
    }

    public void paint(Graphics g) {
      //always 30x40 and green
      g.setColor(Color.GREEN);
      g.fillOval((int) x, (int) y, 30, 40);
    }
}
