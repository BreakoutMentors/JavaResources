import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class GameBoard extends JPanel {
		
	private int BOARD_WIDTH_PIXELS;
	private int BOARD_HEIGHT_PIXELS;
	private int BOARD_WIDTH_SQUARES;
	private int BOARD_HEIGHT_SQUARES;
	private int SQUARE_PIXELS;
	private int BOARD_PIECES[][];
	private String labelValue = "";
	private BufferedImage appleImage;

	public GameBoard(int pixel_width, int pixel_height, int squares_width, int squares_height, int boardPieces[][]){
		
		BOARD_WIDTH_PIXELS = pixel_width;
		BOARD_HEIGHT_PIXELS = pixel_height;
		BOARD_WIDTH_SQUARES = squares_width;
		BOARD_HEIGHT_SQUARES = squares_height;
		SQUARE_PIXELS = pixel_width / squares_width;
		BOARD_PIECES = boardPieces;
		
		try {
			appleImage = ImageIO.read(new File("apple.png"));
		} catch (IOException e) {
			System.out.println(e);
		}
		
		
	}
	
	public void paintComponent(Graphics g) { 
		//setBackground(Color.GREEN);
		super.paintComponent(g);
		
		drawSquareBackgroundColors(g);
		drawPieces(g);
		drawLabel(g);
		
    }
	
	public void setLabel(String newValue) {
		labelValue = newValue;
	}
	
	private void drawLabel(Graphics g){
		g.setColor(Color.WHITE);
		g.fillRect(0, BOARD_HEIGHT_PIXELS, BOARD_WIDTH_PIXELS, BOARD_HEIGHT_PIXELS + 25);
		g.setColor(Color.BLACK);
		//line at bottom of board
		g.drawLine(0, BOARD_HEIGHT_PIXELS, BOARD_WIDTH_PIXELS, BOARD_HEIGHT_PIXELS);
		
		g.drawString(labelValue, BOARD_WIDTH_PIXELS/2 - 25, BOARD_HEIGHT_PIXELS + 18);
		
	}
	
	private void drawSquareBackgroundColors(Graphics g){
		
		for(int i=0; i<BOARD_WIDTH_SQUARES; i++){
			
			//start at the right position and count by 2
			for(int j=0; j<BOARD_HEIGHT_SQUARES; j++){
				g.drawRect(i * SQUARE_PIXELS, j * SQUARE_PIXELS, SQUARE_PIXELS, SQUARE_PIXELS);
			}
		}
	}
	
	private void drawPieces(Graphics g){
		
		//leave a little space between the edge of the square
		int pixelBuffer = 4;
		
		for(int i=0; i<BOARD_WIDTH_SQUARES; i++){
			for(int j=0; j<BOARD_HEIGHT_SQUARES; j++){
				
				int piece = BOARD_PIECES[i][j];
				if(piece != 0){
					
					if(piece == 1) {
						g.setColor(Color.BLACK);
						g.fillRect(i * SQUARE_PIXELS, j*SQUARE_PIXELS, SQUARE_PIXELS, SQUARE_PIXELS);
					} else if (piece == 2) {
						g.drawImage(appleImage, i * SQUARE_PIXELS + pixelBuffer, j*SQUARE_PIXELS + pixelBuffer, SQUARE_PIXELS - 2*pixelBuffer, SQUARE_PIXELS - 2*pixelBuffer, null);
					}		

					
				}
				
			}
		}
		
	}
}