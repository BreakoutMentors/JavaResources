import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

import javax.swing.JPanel;

public class GameBoard extends JPanel {
		
		private int BOARD_SIDE_PIXELS;
		private int BOARD_SIDE_SQUARES;
		private int SQUARE_PIXELS;
		private int BOARD_PIECES[][];
		private String labelValue = "";

		public GameBoard(int pixels_per_side, int squares_per_side, int boardPieces[][]){
			
			BOARD_SIDE_PIXELS = pixels_per_side;
			BOARD_SIDE_SQUARES = squares_per_side;
			SQUARE_PIXELS = pixels_per_side / squares_per_side;
			BOARD_PIECES = boardPieces;
			
			setBackground(Color.black);
			
		}
		
		public void paintComponent(Graphics g) { 

			super.paintComponent(g);
			
			drawSeparatorLines(g);
			drawPieces(g);
			drawLabel(g);

	    }
		
		public void setLabel(String newValue) {
			labelValue = newValue;
		}
		
		public void setBoard(int[][] newBoard){
			BOARD_PIECES = newBoard;
		}
		
		private void drawLabel(Graphics g){

			g.setColor(Color.WHITE);
			g.fillRect(0, BOARD_SIDE_PIXELS, BOARD_SIDE_PIXELS, 27);
			
			g.setColor(Color.BLACK);
			g.drawString(labelValue, BOARD_SIDE_PIXELS/2 - 25, BOARD_SIDE_PIXELS + 18);
			
		}
		
		//not used for checkers, will be used for other games
		private void drawSeparatorLines(Graphics g){
			
			g.setColor(Color.WHITE);
			
			//horizontal lines
			for(int i=1; i<BOARD_SIDE_SQUARES; i++){
				//x is always 0 to board size
				g.drawLine(0, i*SQUARE_PIXELS, BOARD_SIDE_PIXELS, i*SQUARE_PIXELS);
			}
			
			//vertical lines
			for(int i=1; i<BOARD_SIDE_SQUARES; i++){
				//y is always 0 to board size
				g.drawLine(i*SQUARE_PIXELS, 0, i*SQUARE_PIXELS, BOARD_SIDE_PIXELS);
			}
			
		}
		
		
		private void drawPieces(Graphics g){
			
			g.setColor(Color.WHITE);
			
			for(int i=0; i<BOARD_SIDE_SQUARES; i++){
				for(int j=0; j<BOARD_SIDE_SQUARES; j++){
					
					int piece = BOARD_PIECES[i][j];
					if(piece != 0){
						
						g.fillRect(i * SQUARE_PIXELS, j*SQUARE_PIXELS, SQUARE_PIXELS, SQUARE_PIXELS);
					}
					
				}
			}
			
		}
}