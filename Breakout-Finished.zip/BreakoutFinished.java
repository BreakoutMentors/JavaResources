/*
 * File: Breakout.java
 * -------------------
 * Name:
 * Section Leader:
 * 
 * This file will eventually implement the game of Breakout.
 */

import acm.graphics.*;
import acm.program.*;
import acm.util.*;

import java.applet.*;
import java.awt.*;
import java.awt.event.*;

public class BreakoutFinished extends GraphicsProgram {

	/** Width and height of application window in pixels */
	public static final int APPLICATION_WIDTH = 400;
	public static final int APPLICATION_HEIGHT = 600;

	/** Dimensions of game board (usually the same) */
	private static final int WIDTH = APPLICATION_WIDTH;
	private static final int HEIGHT = APPLICATION_HEIGHT;

	/** Dimensions of the paddle */
	private static final int PADDLE_WIDTH = 60;
	private static final int PADDLE_HEIGHT = 10;

	/** Offset of the paddle up from the bottom */
	private static final int PADDLE_Y_OFFSET = 30;

	/** Number of bricks per row */
	private static final int NBRICKS_PER_ROW = 8;

	/** Number of rows of bricks */
	private static final int NBRICK_ROWS = 8;

	/** Separation between bricks */
	private static final int BRICK_SEP = 4;

	/** Width of a brick */
	private static final int BRICK_WIDTH =
		(WIDTH - (NBRICKS_PER_ROW - 1) * BRICK_SEP) / NBRICKS_PER_ROW;

	/** Height of a brick */
	private static final int BRICK_HEIGHT = 8;

	/** Radius of the ball in pixels */
	private static final int BALL_RADIUS = 10;

	/** Offset of the top brick row from the top */
	private static final int BRICK_Y_OFFSET = 70;

	/** Number of turns */
	private static final int NTURNS = 3;

	int PAUSE_TIME = 10;
	
	private RandomGenerator rgen = RandomGenerator.getInstance();
	
	GRect paddle;
	GOval ball;
	double speedX;
	double speedY;
	GLabel status;

	/* Method: run() */
	/** Runs the Breakout program. */
	public void run() {
		//create ball
		ball = new GOval(getWidth()/2, getHeight()/2, BALL_RADIUS, BALL_RADIUS);
		ball.setFilled(true);
		add(ball);

		//create paddle
		paddle = new GRect(getWidth()/2 - PADDLE_WIDTH/2, getHeight() - PADDLE_Y_OFFSET,
				PADDLE_WIDTH, PADDLE_HEIGHT);
		paddle.setFilled(true);
		add(paddle);

		addMouseListeners();
		
		createBricks();
		
		GLabel livesLabel = new GLabel("Lives: 3", 8, 20);
		add(livesLabel);
		
		GLabel scoreLabel = new GLabel("Score: 0", 338, 20);
		add(scoreLabel);
		
		status = new GLabel("", 180,270);
		

		randomBallDirection();
		
		int livesLeft = 3;
		int score = 0;
		
		AudioClip bounceClip = MediaTools.loadAudioClip("bounce.au");
		
		int bricksThisLife = 0;
		
		while(true){
			ball.move(speedX, speedY);
			pause(PAUSE_TIME);

			//bounce off right wall
			if(ball.getX() >= getWidth() - BALL_RADIUS){
				speedX = -speedX;
			}

			//bounce off left wall
			if(ball.getX() <= 0){
				speedX = -speedX;
			}

			//bounce off top wall
			if(ball.getY() <= 0){
				speedY = -speedY;
			}

			//bottom wall
			if(ball.getY() >= getHeight() - BALL_RADIUS){
				livesLeft = livesLeft - 1;
				ball.setLocation(getWidth()/2, getHeight()/2);
				livesLabel.setLabel("Lives: " + livesLeft);
				randomBallDirection();
				bricksThisLife = 0;
				if(livesLeft == 0){
					status.setLabel("You Lost!");
					add(status);
					break;
				}
			}
			
			GObject collidingObject = getCollidingObject();
			//if the ball hit something
			if(collidingObject != null){
				if(collidingObject == paddle){
					//it hit the paddle, only bounce if ball is moving down
					if(speedY > 0){
						speedY = -speedY;
						bounceClip.play();
					}
				}else if(collidingObject == livesLabel){
					//do not remove or bounce off label
				}else if(collidingObject == scoreLabel){
					//do not remove or bounce off label
				}else{
					//it hit a brick
					speedY = -speedY;
					remove(collidingObject);
					score = score + 1;
					bricksThisLife = bricksThisLife + 1;
					scoreLabel.setLabel("Score: " + score);
					bounceClip.play();
					
					if(bricksThisLife == 10 || bricksThisLife == 20 || bricksThisLife == 30){
						speedX = speedX * 1.5;
						speedY = speedY * 1.5;
					}
					
					//if you won the game, stop
					if(score == NBRICK_ROWS * NBRICKS_PER_ROW){
						status.setLabel("You Won!");
						add(status);
						break;
					}
				}
			}
			
			
		}


	}

	public void createBricks(){

		int brickY = 80;

		for(int j=0;j<NBRICK_ROWS;j++){
			
			int brickX = 2;

			for(int i=0; i< NBRICKS_PER_ROW; i++){
				Color color = rgen.nextColor();
				
				GRect brick = new GRect(brickX, brickY, BRICK_WIDTH, BRICK_HEIGHT);
				brick.setFilled(true);
				brick.setFillColor(color);
				brick.setColor(color);
				add(brick);

				brickX = brickX + BRICK_SEP + BRICK_WIDTH;
			}
			
			brickY = brickY + BRICK_SEP + BRICK_HEIGHT;
		}

	}

	
	public void mouseMoved(MouseEvent e) {
		
		paddle.setLocation(e.getX() - PADDLE_WIDTH/2 , getHeight() - PADDLE_Y_OFFSET);
		
		//check if paddle off the screen to the left
		if(paddle.getX() < 0){
			paddle.setLocation(0, getHeight() - PADDLE_Y_OFFSET);
		}
		
		//check if paddle off the screen to the right
		if(paddle.getX() > getWidth() - PADDLE_WIDTH){
			paddle.setLocation(getWidth() - PADDLE_WIDTH, getHeight() - PADDLE_Y_OFFSET);
		}
	}
	
	public GObject getCollidingObject(){
		//check the top left corner
		if( getElementAt(ball.getX(),ball.getY() ) != null){
			return getElementAt(ball.getX(),ball.getY());
		}
		//next check the top right corner
		else if(getElementAt(ball.getX() + BALL_RADIUS,ball.getY() ) != null){
			return getElementAt(ball.getX() + BALL_RADIUS,ball.getY() );
		}
		//next check the bottom left corner
		else if(getElementAt(ball.getX(),ball.getY() + BALL_RADIUS) != null){
			return getElementAt(ball.getX(),ball.getY() + BALL_RADIUS);
		}
		//next check the bottom right corner
		else if(getElementAt(ball.getX()+ BALL_RADIUS,ball.getY() + BALL_RADIUS) != null){
			return getElementAt(ball.getX()+ BALL_RADIUS,ball.getY() + BALL_RADIUS);
		}else{
			return null;
		}
		
	}
	
	public void randomBallDirection(){
		speedX = rgen.nextDouble(1.5, 2.5);
		if (rgen.nextBoolean(0.5)) speedX = -speedX;
		
		speedY = rgen.nextDouble(1.5,2.5);
	}


}
