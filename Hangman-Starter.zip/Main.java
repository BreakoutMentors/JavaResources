/**
 * JuiceMind runs the class called Main, so this just launches the real program.
 * All the actual code lives in Hangman.java, HangmanCanvas.java and HangmanLexicon.java.
 */
public class Main {
    public static void main(String[] args) {
        new Hangman().start(args);
    }
}
