import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JFrame;
import javax.swing.WindowConstants;

public class Checkers extends JFrame implements MouseListener {	

	int boardPieces[][];
	int title_bar_height = 23;
	int squares_per_side = 8;
	int pixels_per_side = 560;
	int label_height = 25;
	
	private Point selected = null;
	private boolean isRedTurn = true;
			
	//Number of pixels wide the square is
	private int sq_pixels = pixels_per_side / squares_per_side;
	GameBoard gb;

	public static void main(String[] args) {  
		new Checkers();  
	}
	
	public Checkers(){  
		
		//set up our game variables
		boardPieces = new int[squares_per_side][squares_per_side];
		setupPieces();
				
		gb = new GameBoard(pixels_per_side, squares_per_side, boardPieces);
		gb.setLabel("Red Turn");
		add(gb);
		
		//set a few things for our JFrame
		setSize(pixels_per_side, pixels_per_side + title_bar_height + label_height);  
		setVisible(true);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		addMouseListener(this);
		
	} 

	public void mouseClicked(MouseEvent e) {
		//Does Integer Division by the size of a square in order to get the number square
		//(i.e. the top leftmost square is square (0, 0), bottom rightmost square is square(7,7)
		
			//getInsets() asks the window how thick its own border and title bar actually are.
		//They are different sizes on Mac, Windows and Linux, so we can't hard-code a number -
		//doing that makes every click land one row off on the platforms where it's wrong.
		java.awt.Insets insets = getInsets();

		int newX = (e.getX() - insets.left) / sq_pixels; 
		int newY = (e.getY() - insets.top) / sq_pixels;

		//ignore clicks that land outside the 8x8 board (like on the label strip)
		if(newX < 0 || newX >= squares_per_side || newY < 0 || newY >= squares_per_side){
			return;
		}
				
		//only allow if black square (We know that it is a black square if the selectedX and selectedY
		//of the square are both even, so it is a black square if they add up to be an even number)
		if( (newX + newY) % 2 == 0){
			
			//If selected is set, we are trying to make a move or jump
			if(selected != null) {
				
				//set variable so only have to call isValidJump once
				boolean jump = isValidJump(newX, newY);
				
				if(isValidRegularMove(newX, newY) || jump){
				
					//update the new spot
					boardPieces[newX][newY] = boardPieces[selected.x][selected.y];
					//set the previous spot to blank
					boardPieces[selected.x][selected.y] = 0;			
		
					if(jump){
						//set the jumped spot blank
						boardPieces[(newX+selected.x)/2][(newY+selected.y)/2] = 0;
					}
					
					selected = null;
					gb.setSelectedSquare(null);
					
					if(isRedTurn) gb.setLabel("Blue Turn");
					if(!isRedTurn) gb.setLabel("Red Turn");
					isRedTurn = !isRedTurn;
				
				}
				
			} else {
				//only allow selecting if you have a piece on that square
				if( (isRedTurn && boardPieces[newX][newY] == 2) || (!isRedTurn && boardPieces[newX][newY] == 1)){
					selected = new Point(newX, newY);
					gb.setSelectedSquare(selected);
				}
			}
			
		}else{
			//clicked a white square, so clear selected
			selected = null;
			gb.setSelectedSquare(null);
		}
		
		this.repaint();

	}

	private boolean isValidJump(int newX, int newY) {
		
		//only should click on empty space
		if(boardPieces[newX][newY] != 0){
			return false;
		}
				
		if(isRedTurn) {
			//red can only jump 2 bottom left or bottom right
			boolean isBottomRight = newX == selected.x+2 && newY == selected.y+2;
			boolean isBottomLeft = newX == selected.x-2 && newY == selected.y+2;
			
			//needs to be other color square in between
			return (isBottomRight && boardPieces[selected.x+1][selected.y+1] == 1) || (isBottomLeft && boardPieces[selected.x-1][selected.y+1] == 1);
		} else {
			//blue can only jump 2 top left or top right
			boolean isTopLeft = newX == selected.x-2 && newY == selected.y-2;
			boolean isTopRight = newX == selected.x+2 && newY == selected.y-2;

			return (isTopRight && boardPieces[selected.x+1][selected.y-1] == 2) || (isTopLeft && boardPieces[selected.x-1][selected.y-1] == 2);
		}		
		
	}
	
	//Returns whether or not the proposed move is valid
	private boolean isValidRegularMove(int newX, int newY) {
		
		//only should click on empty space
		if(boardPieces[newX][newY] != 0){
			return false;
		}
		
		if(isRedTurn) {
			//red can only move bottom left or bottom right
			boolean isBottomRight = newX == selected.x+1 && newY == selected.y+1;
			boolean isBottomLeft = newX == selected.x-1 && newY == selected.y+1;

			return isBottomRight || isBottomLeft;
		} else {
			//blue can only move top left or top right
			boolean isTopLeft = newX == selected.x-1 && newY == selected.y-1;
			boolean isTopRight = newX == selected.x+1 && newY == selected.y-1;

			return isTopLeft || isTopRight;
		}
	}
	
	private void setupPieces(){
		boardPieces[0][0] = 2;
		boardPieces[2][0] = 2;
		boardPieces[4][0] = 2;
		boardPieces[6][0] = 2;
		boardPieces[1][1] = 2;
		boardPieces[3][1] = 2;
		boardPieces[5][1] = 2;
		boardPieces[7][1] = 2;
		boardPieces[0][2] = 2;
		boardPieces[2][2] = 2;
		boardPieces[4][2] = 2;
		boardPieces[6][2] = 2;

		boardPieces[1][5] = 1;
		boardPieces[3][5] = 1;
		boardPieces[5][5] = 1;
		boardPieces[7][5] = 1;
		boardPieces[0][6] = 1;
		boardPieces[2][6] = 1;
		boardPieces[4][6] = 1;
		boardPieces[6][6] = 1;
		boardPieces[1][7] = 1;
		boardPieces[3][7] = 1;
		boardPieces[5][7] = 1;
		boardPieces[7][7] = 1;	
	}
	
	
	/* not using the following mouse listener methods, but need these here */
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
	}
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub		
	}
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub	
	}
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub	
	}


}
